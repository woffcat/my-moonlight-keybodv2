package com.limelight.binding.input.virtual_controller;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Library of real vector (line) icons for the virtual buttons. Each icon is a tiny drawing script
 * on a 24 x 24 grid:
 *   l = open polyline, p = closed outline, fp = filled polygon, c = circle outline,
 *   fc = filled circle, r = (rounded) rectangle outline, fr = filled rectangle,
 *   a = arc (centre x y, radius, start angle, sweep angle in degrees, clockwise from 3 o'clock).
 * The scripts are turned into Path objects once (when a button is sized or restyled) so drawing
 * an icon later is just two canvas.drawPath() calls.
 */
public final class VectorIcons {
    /** Icons are stored in a button's style as "v:" + id. */
    public static final String PREFIX = "v:";
    public static final float STROKE_UNITS = 1.9f;

    public static final class Icon {
        public final String id;
        public final String name;
        final String dsl;

        Icon(String id, String name, String dsl) {
            this.id = id;
            this.name = name;
            this.dsl = dsl;
        }

        public String styleValue() {
            return PREFIX + id;
        }
    }

    public static final class Category {
        public final String name;
        public final List<Icon> icons = new ArrayList<>();

        Category(String name) {
            this.name = name;
        }
    }

    public static final List<Category> CATEGORIES = new ArrayList<>();
    private static final Map<String, Icon> BY_ID = new HashMap<>();

    private static Category cat;

    private static void c(String name) {
        cat = new Category(name);
        CATEGORIES.add(cat);
    }

    private static void i(String id, String name, String dsl) {
        Icon icon = new Icon(id, name, dsl);
        cat.icons.add(icon);
        BY_ID.put(id, icon);
    }

    static {
        c("Directions");
        i("up", "Up", "l 12 19 12 5 | l 6 11 12 5 18 11");
        i("down", "Down", "l 12 5 12 19 | l 6 13 12 19 18 13");
        i("left", "Left", "l 19 12 5 12 | l 11 6 5 12 11 18");
        i("right", "Right", "l 5 12 19 12 | l 13 6 19 12 13 18");
        i("up_left", "Up-left", "l 18 18 6 6 | l 6 15 6 6 15 6");
        i("up_right", "Up-right", "l 6 18 18 6 | l 9 6 18 6 18 15");
        i("down_left", "Down-left", "l 18 6 6 18 | l 6 9 6 18 15 18");
        i("down_right", "Down-right", "l 6 6 18 18 | l 18 9 18 18 9 18");
        i("chev_up", "Chevron up", "l 5 15 12 8 19 15");
        i("chev_down", "Chevron down", "l 5 9 12 16 19 9");
        i("chev_left", "Chevron left", "l 15 5 8 12 15 19");
        i("chev_right", "Chevron right", "l 9 5 16 12 9 19");
        i("fast_up", "Fast up", "l 5 12 12 5 19 12 | l 5 19 12 12 19 19");
        i("fast_down", "Fast down", "l 5 5 12 12 19 5 | l 5 12 12 19 19 12");
        i("tri_up", "Triangle up", "fp 12 5 20 19 4 19");
        i("tri_down", "Triangle down", "fp 4 5 20 5 12 19");
        i("tri_left", "Triangle left", "fp 19 4 19 20 5 12");
        i("tri_right", "Triangle right", "fp 5 4 19 12 5 20");
        i("up_down", "Up-down", "l 12 3 12 21 | l 8 7 12 3 16 7 | l 8 17 12 21 16 17");
        i("left_right", "Left-right", "l 3 12 21 12 | l 7 8 3 12 7 16 | l 17 8 21 12 17 16");
        i("four_way", "Four ways", "l 12 3 12 21 | l 3 12 21 12 | l 9 6 12 3 15 6 | l 9 18 12 21 15 18 | l 6 9 3 12 6 15 | l 18 9 21 12 18 15");
        i("dpad", "D-pad", "p 9 3 15 3 15 9 21 9 21 15 15 15 15 21 9 21 9 15 3 15 3 9 9 9");
        i("compass", "Compass", "c 12 12 9 | p 12 6 14.5 12 12 18 9.5 12 | fc 12 12 1.2");
        c("Movement");
        i("run", "Run", "fc 15.5 4.5 2 | l 13 8 10.5 13.5 | l 13 8.5 17.5 10.5 20 9 | l 13 8.5 9.5 10 8 8 | l 10.5 13.5 14.5 16.5 13.5 21 | l 10.5 13.5 7.5 17 3.5 17.5");
        i("walk", "Walk", "fc 12 4 2 | l 12 7 12 14 | l 12 9 8 12.5 | l 12 9 16 12.5 | l 12 14 9 21 | l 12 14 15 21");
        i("sprint", "Sprint", "l 3 8 10 8 | l 2 12 13 12 | l 3 16 10 16 | l 14 6 21 12 14 18");
        i("jump", "Jump", "l 4 20 20 20 | l 12 16 12 4 | l 7 9 12 4 17 9");
        i("double_jump", "Double jump", "l 12 20 12 7 | l 7 12 12 7 17 12 | l 7 8 12 3 17 8 | l 5 22 19 22");
        i("crouch", "Crouch", "fc 12 5 2 | l 12 8 12 13 | l 12 9.5 8 12.5 | l 12 9.5 16 12.5 | l 12 13 8 16.5 8 21 | l 12 13 16 16.5 16 21");
        i("prone", "Prone", "fc 4.5 14 2 | l 7.5 15 19 15 | l 19 15 22 17 | l 12 15 14 18 18 18 | l 3 21 22 21");
        i("slide", "Slide", "fc 7 6 2 | l 8.5 8.5 13 13.5 | l 13 13.5 20 14.5 | l 13 13.5 9 18.5 | l 9 10 4.5 12.5 | l 3 21 21 21");
        i("dash", "Dash", "l 3 7 9 7 | l 5 12 11 12 | l 3 17 9 17 | fp 12 5 21 12 12 19");
        i("dodge", "Dodge / roll", "a 12 12 8 -40 285 | l 4.48 4.02 8.62 4.75 6.52 8.39");
        i("climb", "Climb", "l 8 3 8 21 | l 16 3 16 21 | l 8 7 16 7 | l 8 12 16 12 | l 8 17 16 17");
        i("swim", "Swim", "fc 16 6 2 | l 14 9 8 12 | l 8 12 3 11 | l 2 16 5 14 8 16 11 14 14 16 17 14 20 16 22 15 | l 2 21 5 19 8 21 11 19 14 21 17 19 20 21 22 20");
        i("fly", "Fly", "l 2 10 7 7 12 13 17 7 22 10 | l 12 13 12 20");
        i("teleport", "Teleport", "c 12 12 3 | a 12 12 7 20 290 | a 12 12 10.5 200 230");
        i("turn", "Turn around", "l 8 5 4 9 8 13 | l 4 9 14 9 | a 14 14 5 -90 180 | l 14 19 8 19");
        i("lean_left", "Lean left", "fc 14 5 2 | l 13 8 11 15 | l 11 15 8 21 | l 11 15 15 21 | l 12.5 9.5 7 9");
        i("lean_right", "Lean right", "fc 10 5 2 | l 11 8 13 15 | l 13 15 16 21 | l 13 15 9 21 | l 11.5 9.5 17 9");
        c("Combat");
        i("attack", "Attack", "l 4 4 15 15 | l 20 4 9 15 | l 12 12 7 17 | l 12 12 17 17 | l 5 18 8 21 | l 19 18 16 21");
        i("sword", "Sword", "l 5 19 17 7 | l 17 7 20 4 20 8 | l 7 12 12 17 | l 3 21 6 18");
        i("shoot", "Shoot", "p 2 8 19 8 19 12 13 12 12.5 18 8 18 9 12 2 12 | l 21 8 23 8 | l 11 10 11 10");
        i("aim", "Aim", "c 12 12 6 | l 12 2 12 7 | l 12 17 12 22 | l 2 12 7 12 | l 17 12 22 12 | fc 12 12 1.2");
        i("scope", "Scope", "c 12 12 9 | l 12 5 12 19 | l 5 12 19 12 | c 12 12 3.5");
        i("reload", "Reload", "a 12 12 8 -50 290 | l 3.82 4.71 8 5.07 6.23 8.88 | fc 12 12 1.6");
        i("grenade", "Grenade", "c 12 14 6.5 | r 10 3.5 4 4 1 | l 14 5 18 3 | l 9 12 9 12");
        i("shield", "Shield", "p 12 3 19 6 19 12 12 21 5 12 5 6");
        i("block", "Block", "p 12 3 19 6 19 12 12 21 5 12 5 6 | l 12 8 12 15 | l 9 11.5 15 11.5");
        i("punch", "Punch", "r 6 9 11 9 3 | l 8.5 9 8.5 5 | l 11.5 9 11.5 4 | l 14.5 9 14.5 5 | l 17 11 20 8 | l 8 18 8 21 15 21 15 18");
        i("bow", "Bow", "a 17 12 10 110 140 | l 17 12 17 12 | l 4 12 21 12 | l 7 9 4 12 7 15");
        i("knife", "Knife", "p 3 21 15 7 19 8 17 12 6 22 | l 15 7 20 4");
        i("hammer", "Hammer", "r 5 4 14 6 1 | l 12 10 12 21");
        i("axe", "Axe", "l 6 21 17 5 | p 13 4 21 5 19 12 14 9");
        i("fire", "Fire", "p 12 2 15.5 7 18.5 11 19 15 16 20 12 22 8 20 5 15 6 11 9 8 10 12 12 8");
        i("magic", "Magic", "p 12 2.5 13.84 10.16 21.5 12 13.84 13.84 12 21.5 10.16 13.84 2.5 12 10.16 10.16 | fp 19 2 19.71 4.29 22 5 19.71 5.71 19 8 18.29 5.71 16 5 18.29 4.29 | fp 5 16.5 5.57 18.43 7.5 19 5.57 19.57 5 21.5 4.43 19.57 2.5 19 4.43 18.43");
        i("lightning", "Lightning", "p 13 2 5 13 11 13 10 22 19 10 13 10");
        i("explosion", "Explosion", "p 12 2 13.91 7.38 19.07 4.93 16.62 10.09 22 12 16.62 13.91 19.07 19.07 13.91 16.62 12 22 10.09 16.62 4.93 19.07 7.38 13.91 2 12 7.38 10.09 4.93 4.93 10.09 7.38");
        i("skull", "Skull", "a 12 10 7.5 180 180 | l 4.5 10 4.5 13 8 14.5 8 19 16 19 16 14.5 19.5 13 19.5 10 | fc 9 11 1.8 | fc 15 11 1.8 | l 11 16 11 19 | l 13 16 13 19");
        i("ammo", "Ammo", "r 5 9 4 11 1.5 | r 10 9 4 11 1.5 | r 15 9 4 11 1.5 | l 5 6 9 6 | l 10 6 14 6 | l 15 6 19 6");
        i("swap", "Swap weapon", "l 4 8 19 8 | l 15 4 19 8 15 12 | l 20 16 5 16 | l 9 12 5 16 9 20");
        i("special", "Special", "p 12 3 14.35 9.26 21.04 9.56 15.8 13.74 17.58 20.19 12 16.5 6.42 20.19 8.2 13.74 2.96 9.56 9.65 9.26");
        i("ultimate", "Ultimate", "p 12 2 14.25 8.1 20.66 7 16.5 12 20.66 17 14.25 15.9 12 22 9.75 15.9 3.34 17 7.5 12 3.34 7 9.75 8.1 | fc 12 12 2");
        i("poison", "Poison", "p 12 3 17.2 12 17.8 13.45 18 15 17.8 16.55 17.2 18 16.24 19.24 15 20.2 13.55 20.8 12 21 10.45 20.8 9 20.2 7.76 19.24 6.8 18 6.2 16.55 6 15 6.2 13.45 6.8 12 6.8 12 | l 10 16 14 16");
        i("ice", "Ice", "l 12 2.5 12 21.5 | l 3.6 7.2 20.4 16.8 | l 3.6 16.8 20.4 7.2 | l 9.5 4.5 12 7 14.5 4.5 | l 9.5 19.5 12 17 14.5 19.5");
        c("Items");
        i("backpack", "Inventory / backpack", "r 6 8 12 13 4 | l 9 8 9 5 15 5 15 8 | l 9 14 15 14");
        i("handbag", "Bag", "r 4 9 16 12 2 | l 8 9 8 6 16 6 16 9");
        i("chest", "Chest", "r 3 9 18 11 1 | l 3 13 21 13 | r 10 11 4 4 1 | l 3 9 5 5 19 5 21 9");
        i("interact", "Interact", "p 6 3 6 18 10 14 13 20 15.5 19 12.5 13 18 13");
        i("use", "Use", "c 12 12 8 | fc 12 12 3");
        i("hand", "Hand", "r 7 10 10 11 3 | l 8.5 10 8.5 4 | l 11.5 10 11.5 3 | l 14.5 10 14.5 4 | l 17 13 20 10");
        i("pickup", "Pick up", "l 12 3 12 13 | l 8 9 12 13 16 9 | l 4 15 4 20 20 20 20 15");
        i("drop", "Drop", "l 12 14 12 4 | l 8 8 12 4 16 8 | l 4 15 4 20 20 20 20 15");
        i("door", "Open door", "r 6 3 12 18 1 | fc 15 12 1.2 | l 3 21 21 21");
        i("key", "Key", "c 8 12 4 | l 12 12 21 12 | l 18 12 18 16 | l 21 12 21 15");
        i("lock", "Lock", "r 5 11 14 10 2 | a 12 11 4.5 180 180 | fc 12 16 1.3");
        i("unlock", "Unlock", "r 5 11 14 10 2 | l 7.5 11 7.5 7.5 | a 12 7.5 4.5 180 180 | fc 12 16 1.3");
        i("potion", "Potion", "p 10 3 14 3 14 9 19 19 19 21 5 21 5 19 10 9 | l 8 15 16 15");
        i("gift", "Gift", "r 4 11 16 10 1 | r 3 7 18 4 1 | l 12 7 12 21 | l 12 7 8 4 | l 12 7 16 4");
        i("coin", "Coin", "c 12 12 9 | c 12 12 5.5");
        i("gem", "Gem", "p 12 21 3 9 7 4 17 4 21 9 | l 3 9 21 9 | l 9 9 12 21 15 9");
        i("book", "Book", "p 3 5 11 6 11 20 3 19 | p 21 5 13 6 13 20 21 19");
        i("note", "Note", "r 5 3 14 18 1 | l 8 8 16 8 | l 8 12 16 12 | l 8 16 13 16");
        i("package", "Package", "p 12 3 21 7 21 17 12 21 3 17 3 7 | l 3 7 12 11 21 7 | l 12 11 12 21");
        i("build", "Build", "l 2 21 22 21 | p 5 21 5 11 12 5 19 11 19 21 | r 10 14 4 7 0");
        i("fishing", "Fishing", "l 3 21 17 4 | l 17 4 17 14 | a 15 16 2 0 260");
        i("pan", "Cook", "c 10 14 6.5 | l 16 11 22 7");
        i("food", "Food", "c 9 14 5.5 | l 13 10 19 4 | c 20.5 3.5 1.8");
        i("cup", "Drink", "p 6 6 18 6 16 21 8 21 | l 12 6 14 2");
        i("flashlight", "Flashlight", "p 8 3 16 3 14 9 10 9 | r 10 9 4 12 1 | l 12 14 12 17");
        i("torch", "Candle", "r 9.5 11 5 10 1 | p 12 2 15 7 12 10 9 7");
        i("trash", "Trash", "l 4 6 20 6 | l 9 6 9 3 15 3 15 6 | p 6 6 7 21 17 21 18 6 | l 10 10 10 17 | l 14 10 14 17");
        c("Health");
        i("heal", "Heal", "r 4 4 16 16 3 | l 12 8 12 16 | l 8 12 16 12");
        i("medkit", "Medkit", "r 3 7 18 13 2 | l 9 7 9 4 15 4 15 7 | l 12 10 12 17 | l 8.5 13.5 15.5 13.5");
        i("heart", "Heart", "p 12 9.2 12.08 8.72 12.6 7.51 13.82 6.18 15.68 5.38 17.82 5.56 19.71 6.75 20.81 8.67 20.81 10.88 19.71 13.06 17.82 15.08 15.68 16.94 13.82 18.65 12.6 20.12 12.08 21.15 12 21.52 11.92 21.15 11.4 20.12 10.18 18.65 8.32 16.94 6.18 15.08 4.29 13.06 3.19 10.88 3.19 8.67 4.29 6.75 6.18 5.56 8.32 5.38 10.18 6.18 11.4 7.51 11.92 8.72 12 9.2");
        i("plus", "Plus", "l 12 5 12 19 | l 5 12 19 12");
        i("minus", "Minus", "l 5 12 19 12");
        i("battery", "Energy", "r 3 8 16 9 2 | l 21 11 21 14 | fr 5.5 10.5 5 4 0.5");
        i("bolt", "Stamina", "fp 13 2 5 13 11 13 10 22 19 10 13 10");
        i("sleep", "Sleep", "p 20.08 14.63 19.77 15.46 19.36 16.25 18.88 17 18.32 17.69 17.69 18.32 17 18.88 16.25 19.36 15.46 19.77 14.63 20.08 13.77 20.31 12.89 20.45 12 20.5 11.11 20.45 10.23 20.31 9.37 20.08 8.54 19.77 7.75 19.36 7 18.88 6.31 18.32 5.68 17.69 5.12 17 4.64 16.25 4.23 15.46 3.92 14.63 3.69 13.77 3.55 12.89 3.5 12 3.55 11.11 3.69 10.23 3.92 9.37 4.23 8.54 4.64 7.75 5.12 7 5.68 6.31 6.31 5.68 7 5.12 7.75 4.64 8.54 4.23 9.37 3.92 10.23 3.69 11.11 3.55 11.3 3.82 10.84 4.39 10.44 5 10.11 5.65 9.84 6.34 9.65 7.04 9.54 7.77 9.5 8.5 9.54 9.23 9.65 9.96 9.84 10.66 10.11 11.35 10.44 12 10.84 12.61 11.3 13.18 11.82 13.7 12.39 14.16 13 14.56 13.65 14.89 14.34 15.16 15.04 15.35 15.77 15.46 16.5 15.5 17.23 15.46 17.96 15.35 18.66 15.16 19.35 14.89 20 14.56");
        i("water", "Water", "p 12 3 17.2 12 17.8 13.45 18 15 17.8 16.55 17.2 18 16.24 19.24 15 20.2 13.55 20.8 12 21 10.45 20.8 9 20.2 7.76 19.24 6.8 18 6.2 16.55 6 15 6.2 13.45 6.8 12 6.8 12");
        i("cure", "Cure", "r 3 9 18 6 3 | l 9 9 9 15 | l 15 9 15 15 | fc 12 12 0.9");
        i("buff", "Buff", "l 12 19 12 6 | l 7 11 12 6 17 11 | l 6 21 18 21");
        i("debuff", "Debuff", "l 12 5 12 18 | l 7 13 12 18 17 13 | l 6 3 18 3");
        i("revive", "Revive", "p 12 9.2 12.08 8.72 12.6 7.51 13.82 6.18 15.68 5.38 17.82 5.56 19.71 6.75 20.81 8.67 20.81 10.88 19.71 13.06 17.82 15.08 15.68 16.94 13.82 18.65 12.6 20.12 12.08 21.15 12 21.52 11.92 21.15 11.4 20.12 10.18 18.65 8.32 16.94 6.18 15.08 4.29 13.06 3.19 10.88 3.19 8.67 4.29 6.75 6.18 5.56 8.32 5.38 10.18 6.18 11.4 7.51 11.92 8.72 12 9.2 | l 12 9 12 15 | l 9 12 15 12");
        i("armor", "Armor", "p 5 4 9 3 12 5 15 3 19 4 19 12 12 21 5 12");
        c("Interface");
        i("map", "Map", "p 3 6 9 4 15 6 21 4 21 18 15 20 9 18 3 20 | l 9 4 9 18 | l 15 6 15 20");
        i("menu", "Menu", "l 4 6 20 6 | l 4 12 20 12 | l 4 18 20 18");
        i("settings", "Settings", "p 10.63 4.93 10.81 2.27 13.19 2.27 13.37 4.93 16.03 6.03 18.03 4.28 19.72 5.97 17.97 7.97 19.07 10.63 21.73 10.81 21.73 13.19 19.07 13.37 17.97 16.03 19.72 18.03 18.03 19.72 16.03 17.97 13.37 19.07 13.19 21.73 10.81 21.73 10.63 19.07 7.97 17.97 5.97 19.72 4.28 18.03 6.03 16.03 4.93 13.37 2.27 13.19 2.27 10.81 4.93 10.63 6.03 7.97 4.28 5.97 5.97 4.28 7.97 6.03 | c 12 12 3");
        i("pause", "Pause", "fr 6 5 4 14 1 | fr 14 5 4 14 1");
        i("play", "Play", "fp 7 4 20 12 7 20");
        i("stop", "Stop", "fr 6 6 12 12 1.5");
        i("record", "Record", "fc 12 12 6.5");
        i("home", "Home", "l 3 12 12 4 21 12 | p 6 11 6 20 18 20 18 11 | r 10 14 4 6 0");
        i("search", "Search", "c 10 10 6 | l 14.5 14.5 21 21");
        i("zoom_in", "Zoom in", "c 10 10 6 | l 14.5 14.5 21 21 | l 7.5 10 12.5 10 | l 10 7.5 10 12.5");
        i("chat", "Chat", "p 4 5 20 5 20 16 11 16 7 20 7 16 4 16");
        i("mic", "Voice", "r 9 3 6 11 3 | a 12 11 6.5 0 180 | l 12 17.5 12 21 | l 9 21 15 21");
        i("mute", "Mute", "p 4 9 8 9 13 5 13 19 8 15 4 15 | l 17 9 22 15 | l 22 9 17 15");
        i("volume", "Volume", "p 3 9 7 9 12 5 12 19 7 15 3 15 | a 12 12 5 -50 100 | a 12 12 9 -50 100");
        i("screenshot", "Screenshot", "r 3 7 18 13 2 | c 12 13.5 3.5 | l 8 7 9.5 4 14.5 4 16 7");
        i("scoreboard", "Scoreboard", "fr 4 12 4 8 1 | fr 10 5 4 15 1 | fr 16 9 4 11 1");
        i("quest", "Quest", "l 12 3 12 14 | fc 12 19 1.6");
        i("question", "Question", "a 12 9 4.5 180 250 | l 12 13.5 12 15 | fc 12 19 1.5");
        i("info", "Info", "c 12 12 9 | l 12 11 12 17 | fc 12 7.5 1.3");
        i("star", "Star", "p 12 3 14.35 9.26 21.04 9.56 15.8 13.74 17.58 20.19 12 16.5 6.42 20.19 8.2 13.74 2.96 9.56 9.65 9.26");
        i("pin", "Pin", "p 12 22 17.63 12.25 18.28 10.68 18.5 9 18.28 7.32 17.63 5.75 16.6 4.4 15.25 3.37 13.68 2.72 12 2.5 10.32 2.72 8.75 3.37 7.4 4.4 6.37 5.75 5.72 7.32 5.5 9 5.72 10.68 6.37 12.25 6.37 12.25 | c 12 9 2.5");
        i("flag", "Flag", "l 6 21 6 3 | p 6 4 19 4 16 8 19 12 6 12");
        i("bell", "Bell", "a 12 11 6 180 180 | l 6 11 6 17 | l 18 11 18 17 | l 4 17 20 17 | l 10 20 14 20");
        i("mail", "Mail", "r 3 5 18 14 2 | l 3 7 12 14 21 7");
        i("check", "Check", "l 5 12.5 10 17.5 19 7");
        i("cross", "Cancel", "l 6 6 18 18 | l 18 6 6 18");
        i("ok", "OK", "c 12 12 9 | l 8 12 11 15 16.5 9");
        i("undo", "Back", "l 9 6 4 11 9 16 | l 4 11 15 11 20 14 20 18");
        i("save", "Save", "p 4 4 17 4 20 7 20 20 4 20 | r 7 4 8 5 0 | r 7 13 10 7 1");
        i("folder", "Load", "p 3 6 10 6 12 8 21 8 21 19 3 19");
        i("phone", "Phone", "r 7 3 10 18 2 | l 11 18 13 18");
        i("team", "Team", "c 9 8 3 | a 9 21 6.5 180 180 | c 17 9 2.5 | a 17 20 5 195 150");
        i("skills", "Skills", "fc 12 5 2.2 | fc 6 17 2.2 | fc 18 17 2.2 | l 12 7 12 11 | l 12 11 6 15 | l 12 11 18 15");
        i("shop", "Shop", "l 2 4 5 4 7 15 19 15 21 7 6 7 | fc 9 19 1.6 | fc 17 19 1.6");
        c("Camera");
        i("camera", "Camera", "r 3 7 18 13 2 | c 12 13.5 3.5 | l 8 7 9.5 4 14.5 4 16 7");
        i("video", "Video", "r 3 6 13 12 2 | p 16 10 21 7 21 17 16 14");
        i("eye", "Eye", "p 2.5 12 4.4 9.99 6.3 8.18 8.2 6.74 10.1 5.82 12 5.5 13.9 5.82 15.8 6.74 17.7 8.18 19.6 9.99 21.5 12 19.6 14.01 17.7 15.82 15.8 17.26 13.9 18.18 12 18.5 10.1 18.18 8.2 17.26 6.3 15.82 4.4 14.01 | c 12 12 3");
        i("rotate_cam", "Rotate camera", "a 12 12 8 -40 285 | l 4.48 4.02 8.62 4.75 6.52 8.39 | fc 12 12 2");
        i("focus", "Lock on", "l 4 9 4 4 9 4 | l 15 4 20 4 20 9 | l 20 15 20 20 15 20 | l 9 20 4 20 4 15 | fc 12 12 2");
        i("person", "Third person", "c 12 8 4 | a 12 22 8 180 180");
        i("sun", "Brightness", "c 12 12 4 | l 19 12 22 12 | l 16.95 16.95 19.07 19.07 | l 12 19 12 22 | l 7.05 16.95 4.93 19.07 | l 5 12 2 12 | l 7.05 7.05 4.93 4.93 | l 12 5 12 2 | l 16.95 7.05 19.07 4.93");
        i("moon", "Night vision", "p 20.08 14.63 19.77 15.46 19.36 16.25 18.88 17 18.32 17.69 17.69 18.32 17 18.88 16.25 19.36 15.46 19.77 14.63 20.08 13.77 20.31 12.89 20.45 12 20.5 11.11 20.45 10.23 20.31 9.37 20.08 8.54 19.77 7.75 19.36 7 18.88 6.31 18.32 5.68 17.69 5.12 17 4.64 16.25 4.23 15.46 3.92 14.63 3.69 13.77 3.55 12.89 3.5 12 3.55 11.11 3.69 10.23 3.92 9.37 4.23 8.54 4.64 7.75 5.12 7 5.68 6.31 6.31 5.68 7 5.12 7.75 4.64 8.54 4.23 9.37 3.92 10.23 3.69 11.11 3.55 11.3 3.82 10.84 4.39 10.44 5 10.11 5.65 9.84 6.34 9.65 7.04 9.54 7.77 9.5 8.5 9.54 9.23 9.65 9.96 9.84 10.66 10.11 11.35 10.44 12 10.84 12.61 11.3 13.18 11.82 13.7 12.39 14.16 13 14.56 13.65 14.89 14.34 15.16 15.04 15.35 15.77 15.46 16.5 15.5 17.23 15.46 17.96 15.35 18.66 15.16 19.35 14.89 20 14.56");
        c("Vehicles");
        i("car", "Car", "p 3 16 3 12 6 12 8.5 7 15.5 7 18 12 21 12 21 16 | l 3 16 21 16 | c 7.5 17 2 | c 16.5 17 2");
        i("truck", "Truck", "r 2 7 12 10 1 | p 14 10 18.5 10 22 13.5 22 17 14 17 | c 6.5 18 2 | c 17.5 18 2");
        i("motorbike", "Motorbike", "c 5.5 16 3.5 | c 18.5 16 3.5 | l 5.5 16 9.5 9 14 9 18.5 16 | l 10 9 8.5 6 11.5 6");
        i("bicycle", "Bicycle", "c 6 16 4 | c 18 16 4 | l 6 16 10 9 15 9 18 16 | l 10 9 13 16 6 16 | l 15 9 14 6 17 6");
        i("plane", "Plane", "p 12 2 14 9 22 14 22 16 14 13.5 14 19 17 21 17 22 12 21 7 22 7 21 10 19 10 13.5 2 16 2 14 10 9");
        i("helicopter", "Helicopter", "l 3 5 17 5 | l 10 5 10 8 | a 10 12.5 5 -90 360 | l 15 12 22 10 | l 7 18 7 21 14 21");
        i("boat", "Boat", "p 3 15 21 15 18 20 6 20 | l 12 15 12 3 | p 12 4 19 13 12 13");
        i("rocket", "Rocket", "p 12 2 16 8 16 16 8 16 8 8 | l 8 15 5 19 8 18 | l 16 15 19 19 16 18 | c 12 10 2 | l 10 19 12 22 14 19");
        i("brake", "Brake", "c 12 12 9 | l 12 7 12 13 | fc 12 16.5 1.3");
        i("horn", "Horn", "p 3 10 8 10 15 5 15 19 8 14 3 14 | l 18 9 21 8 | l 18 12 21 12 | l 18 15 21 16");
        i("headlight", "Headlights", "c 11 10 5 | l 9 16 13 16 | l 9.5 19 12.5 19 | l 18 6 22 5 | l 18 10 22 10 | l 18 14 22 15");
        i("fuel", "Fuel", "r 5 4 9 17 1 | r 7 7 5 4 0 | l 14 10 18 10 18 17 | l 18 12 20 12");
        i("steering", "Steering wheel", "c 12 12 9 | c 12 12 2 | l 3 12 10 12 | l 14 12 21 12 | l 12 14 12 21");
        i("enter_car", "Enter vehicle", "p 2 17 2 13 5 13 7 9 13 9 15 13 17 13 17 17 | l 2 17 17 17 | c 6 18 1.6 | c 13 18 1.6 | l 19 8 23 8 | l 21 6 23 8 21 10");
        i("traffic", "Traffic light", "r 8 2 8 20 3 | fc 12 7 1.5 | fc 12 12 1.5 | fc 12 17 1.5");
        c("Social & emotes");
        i("smile", "Emote", "c 12 12 9 | fc 9 10 1.1 | fc 15 10 1.1 | a 12 12.5 5 25 130");
        i("angry", "Angry", "c 12 12 9 | l 7 8 10.5 10 | l 17 8 13.5 10 | a 12 18 4 205 130");
        i("thumbs_up", "Thumbs up", "r 3 11 4 9 1 | p 7 11 11 3 13.5 3.5 13 9 19 9 20 11 18 19 7 19");
        i("thumbs_down", "Thumbs down", "r 3 4 4 9 1 | p 7 13 11 21 13.5 20.5 13 15 19 15 20 13 18 5 7 5");
        i("music", "Dance / music", "l 9 18 9 5 17 3 17 16 | c 7 18 2 | c 15 16 2");
        i("party", "Cheer", "p 12 2 14.47 9.53 22 12 14.47 14.47 12 22 9.53 14.47 2 12 9.53 9.53 | l 3 3 6 6 | l 21 3 18 6");
        i("ping", "Ping", "fc 12 12 2 | c 12 12 6 | c 12 12 10");
        i("devil", "Taunt", "c 12 13 8 | l 6 7 5 2 9 5 | l 18 7 19 2 15 5 | fc 9.5 12 1.1 | fc 14.5 12 1.1 | l 8.5 16.5 12 18.5 15.5 16.5");
        c("Controller & misc");
        i("gamepad", "Gamepad", "r 2 7 20 11 5 | l 7 10 7 15 | l 4.5 12.5 9.5 12.5 | fc 16 11 1.1 | fc 18.5 13.5 1.1");
        i("joystick", "Joystick", "fc 12 6 3 | l 12 9 12 16 | r 5 16 14 5 1.5");
        i("dice", "Dice", "r 4 4 16 16 3 | fc 8.5 8.5 1.3 | fc 15.5 15.5 1.3 | fc 12 12 1.3 | fc 15.5 8.5 1.3 | fc 8.5 15.5 1.3");
        i("trophy", "Trophy", "p 7 4 17 4 16 11 8 11 | l 12 11 12 16 | l 8 20 16 20 | l 9.5 16 14.5 16 | l 7 6 4 6 4 9 7 10 | l 17 6 20 6 20 9 17 10");
        i("medal", "Medal", "c 12 15 5 | l 8.5 3 11 10 | l 15.5 3 13 10");
        i("clock", "Clock", "c 12 12 9 | l 12 6.5 12 12 16 14");
        i("hourglass", "Hourglass", "p 6 3 18 3 12 12 | p 12 12 18 21 6 21");
        i("tree", "Tree", "p 12 2 18 11 6 11 | p 12 8 19 18 5 18 | l 12 18 12 22");
        i("mountain", "Mountain", "p 2 20 9 8 13 14 16 10 22 20");
        i("tent", "Camp", "p 2 20 12 4 22 20 | l 12 12 12 20 | l 2 20 22 20");
        i("paw", "Paw", "fc 12 15.5 3.8 | fc 6.5 11 1.9 | fc 10 7 1.9 | fc 14 7 1.9 | fc 17.5 11 1.9");
        i("robot", "Robot", "r 5 8 14 11 3 | fc 9 13 1.4 | fc 15 13 1.4 | l 12 8 12 4 | fc 12 3.5 1.1 | l 9 17 15 17");
        i("ghost", "Ghost", "a 12 10 7 180 180 | l 5 10 5 21 8.5 18.5 12 21 15.5 18.5 19 21 19 10 | fc 9.5 10 1.2 | fc 14.5 10 1.2");
        i("cloud", "Cloud", "a 8 14 4 90 180 | a 13 10 5 180 190 | a 18 14 3.5 -90 180 | l 8 18 18 17.5");
        i("wind", "Wind", "l 3 9 14 9 | a 14 7 2 90 -270 | l 3 14 18 14 | a 18 16 2 -90 270 | l 3 19 11 19");
        c("Keys & symbols");
        i("k_shift", "Shift", "p 12 4 20 13 15 13 15 20 9 20 9 13 4 13");
        i("k_ctrl", "Ctrl", "l 6 16 12 9 18 16");
        i("k_alt", "Alt", "l 4 8 9 8 15 17 20 17 | l 14 8 20 8");
        i("k_tab", "Tab", "l 3 12 17 12 | l 13 8 17 12 13 16 | l 21 6 21 18");
        i("k_enter", "Enter", "l 20 6 20 13 8 13 | l 12 9 8 13 12 17");
        i("k_back", "Backspace", "p 8 5 21 5 21 19 8 19 3 12 | l 12 9 17 15 | l 17 9 12 15");
        i("k_space", "Space", "l 4 10 4 16 20 16 20 10");
        i("circle", "Circle", "c 12 12 8");
        i("disc", "Disc", "fc 12 12 8");
        i("square", "Square", "r 5 5 14 14 1.5");
        i("diamond", "Diamond", "p 12 3 21 12 12 21 3 12");
        i("hex", "Hexagon", "p 21.5 12 16.75 20.23 7.25 20.23 2.5 12 7.25 3.77 16.75 3.77");
        i("dots", "Dots", "fc 6 12 1.8 | fc 12 12 1.8 | fc 18 12 1.8");
        i("mouse_l", "Left click", "r 6 3 12 18 6 | l 12 3 12 11 | l 6 11 18 11 | fr 7 4 5 7 0");
        i("mouse_r", "Right click", "r 6 3 12 18 6 | l 12 3 12 11 | l 6 11 18 11 | fr 12 4 5 7 0");
        i("mouse_m", "Middle click", "r 6 3 12 18 6 | l 12 3 12 11 | l 6 11 18 11 | fr 10.5 4 3 6 0");
        i("wheel_up", "Wheel up", "r 7 8 10 14 5 | l 12 12 12 15 | l 9 5 12 2 15 5");
        i("wheel_down", "Wheel down", "r 7 2 10 14 5 | l 12 6 12 9 | l 9 19 12 22 15 19");
    }

    public static boolean isVector(String styleIcon) {
        return styleIcon != null && styleIcon.startsWith(PREFIX);
    }

    /** Finds an icon from a style value ("v:run"), or null. */
    public static Icon find(String styleIcon) {
        if (!isVector(styleIcon)) {
            return null;
        }
        return BY_ID.get(styleIcon.substring(PREFIX.length()));
    }

    public static int totalCount() {
        return BY_ID.size();
    }

    /**
     * Turns an icon into paths placed inside the square (left, top, size). Stroke paths are meant to
     * be drawn with a round-capped stroke of {@link #strokeWidth(float)}, fill paths with a fill paint.
     */
    public static void build(Icon icon, float left, float top, float size, Path strokeOut, Path fillOut) {
        strokeOut.reset();
        fillOut.reset();

        for (String part : icon.dsl.split("\\|")) {
            String[] t = part.trim().split("\\s+");
            if (t.length == 0 || t[0].isEmpty()) {
                continue;
            }
            float[] a = new float[t.length - 1];
            for (int k = 1; k < t.length; k++) {
                a[k - 1] = Float.parseFloat(t[k]);
            }

            String op = t[0];
            if (op.equals("l") || op.equals("p") || op.equals("fp")) {
                Path target = op.equals("fp") ? fillOut : strokeOut;
                for (int k = 0; k + 1 < a.length; k += 2) {
                    if (k == 0) {
                        target.moveTo(a[0], a[1]);
                    }
                    else {
                        target.lineTo(a[k], a[k + 1]);
                    }
                }
                if (!op.equals("l")) {
                    target.close();
                }
            }
            else if (op.equals("c")) {
                strokeOut.addCircle(a[0], a[1], a[2], Path.Direction.CW);
            }
            else if (op.equals("fc")) {
                fillOut.addCircle(a[0], a[1], a[2], Path.Direction.CW);
            }
            else if (op.equals("r")) {
                strokeOut.addRoundRect(new RectF(a[0], a[1], a[0] + a[2], a[1] + a[3]), a[4], a[4], Path.Direction.CW);
            }
            else if (op.equals("fr")) {
                fillOut.addRoundRect(new RectF(a[0], a[1], a[0] + a[2], a[1] + a[3]), a[4], a[4], Path.Direction.CW);
            }
            else if (op.equals("a")) {
                strokeOut.arcTo(new RectF(a[0] - a[2], a[1] - a[2], a[0] + a[2], a[1] + a[2]), a[3], a[4], true);
            }
        }

        Matrix m = new Matrix();
        m.setScale(size / 24f, size / 24f);
        m.postTranslate(left, top);
        strokeOut.transform(m);
        fillOut.transform(m);
    }

    public static float strokeWidth(float size) {
        return STROKE_UNITS * size / 24f;
    }

    /** Prepares a paint pair for drawing icon paths. */
    public static void setupPaints(Paint stroke, Paint fill, float size, int color) {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        stroke.setStrokeWidth(strokeWidth(size));
        stroke.setColor(color);
        stroke.setAntiAlias(true);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        fill.setAntiAlias(true);
    }

    /** Convenience for one-off drawing (previews, picker cells). Allocates, so not for per-frame use. */
    public static void drawOnce(Canvas canvas, Icon icon, float left, float top, float size, int color) {
        Path s = new Path();
        Path f = new Path();
        build(icon, left, top, size, s, f);
        Paint ps = new Paint();
        Paint pf = new Paint();
        setupPaints(ps, pf, size, color);
        canvas.drawPath(s, ps);
        canvas.drawPath(f, pf);
    }
}
