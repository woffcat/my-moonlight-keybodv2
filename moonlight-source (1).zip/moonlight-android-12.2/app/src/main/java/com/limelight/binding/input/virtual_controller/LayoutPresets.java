package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.DisplayMetrics;
import android.view.KeyEvent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Ready-to-use layouts. Positions use the same grid as the stock gamepad layout:
 * 72 units = screen height. Items anchored right ('R') are measured from the right edge,
 * 'C' from the centre, 'L' from the left edge.
 */
public final class LayoutPresets {
    public static final String BASE_GAMEPAD = "gamepad";
    public static final String BASE_NONE = "none";

    public static final class Item {
        public final String type;
        public final char anchor;
        public final float x;
        public final float y;
        public final float size;
        public final float widthFactor;
        public final Binding binding;
        public final String icon;
        public final String label;

        Item(String type, char anchor, float x, float y, float size, float widthFactor,
             Binding binding, String icon, String label) {
            this.type = type;
            this.anchor = anchor;
            this.x = x;
            this.y = y;
            this.size = size;
            this.widthFactor = widthFactor;
            this.binding = binding;
            this.icon = icon;
            this.label = label;
        }
    }

    public static final class Preset {
        public final String id;
        public final String name;
        public final String nameTh;
        public final String description;
        public final boolean keepGamepad;
        public final List<Item> items;

        Preset(String id, String name, String nameTh, String description, boolean keepGamepad, List<Item> items) {
            this.id = id;
            this.name = name;
            this.nameTh = nameTh;
            this.description = description;
            this.keepGamepad = keepGamepad;
            this.items = items;
        }
    }

    public static final List<Preset> ALL = new ArrayList<>();

    private static List<Item> list() {
        return new ArrayList<>();
    }

    static {
        ALL.add(new Preset("gamepad", "Gamepad (Moonlight default)", "\u0e08\u0e2d\u0e22\u0e40\u0e01\u0e21\u0e41\u0e1e\u0e14 (\u0e04\u0e48\u0e32\u0e40\u0e23\u0e34\u0e48\u0e21\u0e15\u0e49\u0e19)",
                "Stick, D-pad, A/B/X/Y and triggers", true, list()));
        {
            List<Item> p = list();
            p.add(new Item("key", 'L', 14f, 34f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_W), "", "W"));
            p.add(new Item("key", 'L', 3f, 45f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_A), "", "A"));
            p.add(new Item("key", 'L', 14f, 45f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_S), "", "S"));
            p.add(new Item("key", 'L', 25f, 45f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_D), "", "D"));
            p.add(new Item("key", 'L', 3f, 58f, 11f, 2f, Binding.ofKeys(KeyEvent.KEYCODE_SHIFT_LEFT), "", "Shift"));
            p.add(new Item("key", 'L', 28f, 58f, 11f, 1.6f, Binding.ofKeys(KeyEvent.KEYCODE_CTRL_LEFT), "", "Ctrl"));
            p.add(new Item("key", 'C', 0f, 60f, 11f, 5f, Binding.ofKeys(KeyEvent.KEYCODE_SPACE), "", "Space"));
            p.add(new Item("key", 'R', 4f, 34f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_E), "", "E"));
            p.add(new Item("key", 'R', 16f, 34f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_Q), "", "Q"));
            p.add(new Item("key", 'R', 28f, 34f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_R), "", "R"));
            p.add(new Item("key", 'R', 4f, 46f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_F), "", "F"));
            p.add(new Item("key", 'R', 16f, 46f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_G), "", "G"));
            p.add(new Item("key", 'R', 4f, 58f, 11f, 2f, Binding.ofKeys(KeyEvent.KEYCODE_ENTER), "", "Enter"));
            p.add(new Item("key", 'R', 3f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_ESCAPE), "", "Esc"));
            p.add(new Item("key", 'R', 14f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_TAB), "", "Tab"));
            p.add(new Item("key", 'R', 25f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_M), "", "M"));
            ALL.add(new Preset("keyboard", "Standard keyboard", "\u0e04\u0e35\u0e22\u0e4c\u0e1a\u0e2d\u0e23\u0e4c\u0e14\u0e21\u0e32\u0e15\u0e23\u0e10\u0e32\u0e19", "WASD, Shift, Ctrl, Space, E/Q/R/F/G, Enter, Esc, Tab", false, p));
        }
        {
            List<Item> p = list();
            p.add(new Item("key", 'L', 14f, 34f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_W), "v:up", null));
            p.add(new Item("key", 'L', 3f, 45f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_A), "v:left", null));
            p.add(new Item("key", 'L', 14f, 45f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_S), "v:down", null));
            p.add(new Item("key", 'L', 25f, 45f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_D), "v:right", null));
            p.add(new Item("key", 'L', 3f, 58f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_SHIFT_LEFT), "v:run", "Run"));
            p.add(new Item("key", 'L', 16f, 58f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_CTRL_LEFT), "v:crouch", "Crouch"));
            p.add(new Item("key", 'R', 6f, 50f, 14f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_SPACE), "v:jump", "Jump"));
            p.add(new Item("key", 'R', 23f, 43f, 13f, 1f, Binding.ofMouse(Binding.MOUSE_LEFT), "v:attack", "Attack"));
            p.add(new Item("key", 'R', 23f, 58f, 13f, 1f, Binding.ofMouse(Binding.MOUSE_RIGHT), "v:aim", "Aim"));
            p.add(new Item("key", 'R', 38f, 48f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_E), "v:interact", "Use"));
            p.add(new Item("key", 'R', 38f, 34f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_R), "v:reload", "Reload"));
            p.add(new Item("key", 'R', 3f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_TAB), "v:backpack", "Bag"));
            p.add(new Item("key", 'R', 14f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_M), "v:map", "Map"));
            p.add(new Item("key", 'R', 25f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_ESCAPE), "v:menu", "Menu"));
            ALL.add(new Preset("gaming", "Common gaming controls", "\u0e1b\u0e38\u0e48\u0e21\u0e40\u0e25\u0e48\u0e19\u0e40\u0e01\u0e21\u0e17\u0e31\u0e48\u0e27\u0e44\u0e1b", "Move, jump, run, crouch, attack, aim, use, reload, bag, map, menu", false, p));
        }
        {
            List<Item> p = list();
            p.add(new Item("wasd", 'L', 4f, 38f, 30f, 1f, null, "", null));
            p.add(new Item("key", 'L', 38f, 56f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_SHIFT_LEFT), "v:run", "Run"));
            p.add(new Item("key", 'L', 38f, 43f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_CTRL_LEFT), "v:crouch", "Crouch"));
            p.add(new Item("key", 'R', 6f, 50f, 14f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_SPACE), "v:jump", "Jump"));
            p.add(new Item("key", 'R', 23f, 43f, 13f, 1f, Binding.ofMouse(Binding.MOUSE_LEFT), "v:attack", "Attack"));
            p.add(new Item("key", 'R', 23f, 58f, 13f, 1f, Binding.ofMouse(Binding.MOUSE_RIGHT), "v:aim", "Aim"));
            p.add(new Item("key", 'R', 38f, 48f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_E), "v:interact", "Use"));
            p.add(new Item("key", 'R', 38f, 34f, 11f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_R), "v:reload", "Reload"));
            p.add(new Item("key", 'R', 3f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_TAB), "v:backpack", "Bag"));
            p.add(new Item("key", 'R', 14f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_M), "v:map", "Map"));
            p.add(new Item("key", 'R', 25f, 3f, 9f, 1f, Binding.ofKeys(KeyEvent.KEYCODE_ESCAPE), "v:menu", "Menu"));
            ALL.add(new Preset("joystick", "WASD joystick", "\u0e08\u0e2d\u0e22\u0e2a\u0e15\u0e34\u0e4a\u0e01 WASD", "Round joystick for movement + the common action buttons", false, p));
        }
    }

    public static Preset byId(String id) {
        for (Preset p : ALL) {
            if (p.id.equals(id)) {
                return p;
            }
        }
        return ALL.get(0);
    }

    /**
     * Replaces the layout of the active profile with a preset. The profile's theme is kept.
     */
    public static void apply(Context context, Preset preset) {
        SharedPreferences prefs = ProfileStore.prefs(context);
        String theme = prefs.getString(VirtualControllerConfigurationLoader.THEME_KEY, ControlTheme.GAMEHUB.id);

        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        final int screenW = Math.max(dm.widthPixels, dm.heightPixels);
        final int screenH = Math.min(dm.widthPixels, dm.heightPixels);
        final float unit = screenH / 72f;

        SharedPreferences.Editor e = prefs.edit();
        e.clear();
        e.putString(VirtualControllerConfigurationLoader.THEME_KEY, theme);
        e.putString(VirtualControllerConfigurationLoader.BASE_KEY, preset.keepGamepad ? BASE_GAMEPAD : BASE_NONE);

        JSONArray custom = new JSONArray();
        int nextId = VirtualControllerElement.EID_CUSTOM_BASE;

        for (Item item : preset.items) {
            int id = nextId++;
            try {
                JSONObject o = new JSONObject();
                o.put("id", id);
                o.put("type", item.type);
                if (item.binding != null) {
                    JSONObject b = item.binding.toJson();
                    o.put("keys", b.getJSONArray("keys"));
                    o.put("mouse", b.getJSONArray("mouse"));
                }
                custom.put(o);

                ControlStyle style = new ControlStyle();
                style.icon = item.icon;
                style.label = item.label;
                e.putString(VirtualControllerConfigurationLoader.STYLE_PREFIX + id, style.toJson());

                int size = Math.round(item.size * unit);
                int width = Math.round(size * item.widthFactor);
                int left;
                switch (item.anchor) {
                    case 'R':
                        left = Math.round(screenW - item.x * unit - width);
                        break;
                    case 'C':
                        left = Math.round(screenW / 2f + item.x * unit - width / 2f);
                        break;
                    default:
                        left = Math.round(item.x * unit);
                        break;
                }
                JSONObject pos = new JSONObject();
                pos.put("LEFT", Math.max(0, left));
                pos.put("TOP", Math.round(item.y * unit));
                pos.put("WIDTH", width);
                pos.put("HEIGHT", size);
                e.putString("" + id, pos.toString());
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
        }

        e.putString(VirtualControllerConfigurationLoader.CUSTOM_ELEMENTS_KEY, custom.toString());
        e.putInt(VirtualControllerConfigurationLoader.CUSTOM_NEXT_ID_KEY, nextId);
        e.apply();
    }
}
