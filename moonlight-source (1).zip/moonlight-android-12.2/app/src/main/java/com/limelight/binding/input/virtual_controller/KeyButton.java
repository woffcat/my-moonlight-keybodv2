package com.limelight.binding.input.virtual_controller;

import android.content.Context;

/**
 * A virtual button that presses a keyboard / mouse {@link Binding} (any number of keys and mouse
 * inputs together). The binding is read at press time so it can be edited while the button exists.
 */
public class KeyButton extends DigitalButton {
    private static final long WHEEL_REPEAT_MS = 90;

    private Binding binding;
    private boolean held = false;

    private final Runnable wheelRepeat = new Runnable() {
        @Override
        public void run() {
            if (!held) {
                return;
            }
            sendWheel();
            virtualController.getHandler().postDelayed(this, WHEEL_REPEAT_MS);
        }
    };

    public KeyButton(VirtualController controller, int elementId, Binding binding, Context context) {
        // Every key button gets its own "layer" so sliding a finger across buttons does not
        // press the neighbouring ones (that only makes sense for gamepad face buttons).
        super(controller, elementId, 10000 + elementId, context);
        this.binding = binding;

        addDigitalButtonListener(new DigitalButtonListener() {
            @Override
            public void onClick() {
                press();
            }

            @Override
            public void onLongClick() {
                // The keys simply stay held
            }

            @Override
            public void onRelease() {
                release();
            }
        });
    }

    public Binding getBinding() {
        return binding;
    }

    public void setBinding(Binding newBinding) {
        if (held) {
            release();
        }
        this.binding = newBinding;
        // Rebuilds the cached label / icon
        setStyle(getStyle());
    }

    @Override
    public String getDefaultLabel() {
        return binding.describe();
    }

    @Override
    public boolean supportsBinding() {
        return true;
    }

    private boolean hasWheel() {
        for (int m : binding.mouse) {
            if (m == Binding.WHEEL_UP || m == Binding.WHEEL_DOWN) {
                return true;
            }
        }
        return false;
    }

    private void sendWheel() {
        for (int m : binding.mouse) {
            if (m == Binding.WHEEL_UP) {
                virtualController.sendScroll(1);
            }
            else if (m == Binding.WHEEL_DOWN) {
                virtualController.sendScroll(-1);
            }
        }
    }

    private void press() {
        if (held) {
            return;
        }
        held = true;

        for (int k : binding.keys) {
            virtualController.sendKey(k, true);
        }
        for (int m : binding.mouse) {
            if (m != Binding.WHEEL_UP && m != Binding.WHEEL_DOWN) {
                virtualController.sendMouseButton(m, true);
            }
        }

        if (hasWheel()) {
            sendWheel();
            // Keep scrolling while the button is held, but only then (no idle timers)
            virtualController.getHandler().postDelayed(wheelRepeat, 350);
        }
    }

    private void release() {
        if (!held) {
            return;
        }
        held = false;
        virtualController.getHandler().removeCallbacks(wheelRepeat);

        for (int i = binding.mouse.length - 1; i >= 0; i--) {
            int m = binding.mouse[i];
            if (m != Binding.WHEEL_UP && m != Binding.WHEEL_DOWN) {
                virtualController.sendMouseButton(m, false);
            }
        }
        for (int i = binding.keys.length - 1; i >= 0; i--) {
            virtualController.sendKey(binding.keys[i], false);
        }
    }

    @Override
    public void releaseAll() {
        super.releaseAll();
        release();
    }
}
