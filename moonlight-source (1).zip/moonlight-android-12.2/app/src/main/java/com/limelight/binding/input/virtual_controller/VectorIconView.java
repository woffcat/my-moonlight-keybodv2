package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Small view that shows one vector icon (used by the icon picker). Paths are built once per size. */
public class VectorIconView extends View {
    private VectorIcons.Icon icon;
    private int color = 0xFFFFFFFF;
    private final Path strokePath = new Path();
    private final Path fillPath = new Path();
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean valid = false;

    public VectorIconView(Context context) {
        super(context);
    }

    public void setIcon(VectorIcons.Icon icon) {
        this.icon = icon;
        valid = false;
        invalidate();
    }

    public void setColor(int color) {
        this.color = color;
        valid = false;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        valid = false;
        super.onSizeChanged(w, h, oldw, oldh);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (icon == null) {
            return;
        }
        if (!valid) {
            float size = Math.min(getWidth(), getHeight()) * 0.7f;
            VectorIcons.build(icon, (getWidth() - size) / 2f, (getHeight() - size) / 2f, size, strokePath, fillPath);
            VectorIcons.setupPaints(strokePaint, fillPaint, size, color);
            valid = true;
        }
        canvas.drawPath(strokePath, strokePaint);
        canvas.drawPath(fillPath, fillPaint);
    }
}
