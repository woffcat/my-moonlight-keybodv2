/**
 * Created by Karim Mreisi.
 */

package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.DisplayMetrics;

import com.limelight.nvstream.input.ControllerPacket;
import com.limelight.preferences.PreferenceConfiguration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VirtualControllerConfigurationLoader {
    public static final String OSC_PREFERENCE = "OSC";

    public static final String CUSTOM_ELEMENTS_KEY = "custom_elements";
    public static final String CUSTOM_NEXT_ID_KEY = "custom_next_id";
    public static final String DELETED_ELEMENTS_KEY = "deleted_elements";
    public static final String STYLE_PREFIX = "style_";
    public static final String THEME_KEY = "theme";
    public static final String BASE_KEY = "base";

    public static final String TYPE_KEY = "key";
    public static final String TYPE_PAD = "pad";
    public static final String TYPE_WASD = "wasd";

    private static int getPercent(
            int percent,
            int total) {
        return (int) (((float) total / (float) 100) * (float) percent);
    }

    // The default controls are specified using a grid of 128*72 cells at 16:9
    private static int screenScale(int units, int height) {
        return (int) (((float) height / (float) 72) * (float) units);
    }

    private static DigitalPad createDigitalPad(
            final VirtualController controller,
            final Context context) {

        DigitalPad digitalPad = new DigitalPad(controller, context);
        digitalPad.addDigitalPadListener(new DigitalPad.DigitalPadListener() {
            @Override
            public void onDirectionChange(int direction) {
                VirtualController.ControllerInputContext inputContext =
                        controller.getControllerInputContext();

                if ((direction & DigitalPad.DIGITAL_PAD_DIRECTION_LEFT) != 0) {
                    inputContext.inputMap |= ControllerPacket.LEFT_FLAG;
                }
                else {
                    inputContext.inputMap &= ~ControllerPacket.LEFT_FLAG;
                }
                if ((direction & DigitalPad.DIGITAL_PAD_DIRECTION_RIGHT) != 0) {
                    inputContext.inputMap |= ControllerPacket.RIGHT_FLAG;
                }
                else {
                    inputContext.inputMap &= ~ControllerPacket.RIGHT_FLAG;
                }
                if ((direction & DigitalPad.DIGITAL_PAD_DIRECTION_UP) != 0) {
                    inputContext.inputMap |= ControllerPacket.UP_FLAG;
                }
                else {
                    inputContext.inputMap &= ~ControllerPacket.UP_FLAG;
                }
                if ((direction & DigitalPad.DIGITAL_PAD_DIRECTION_DOWN) != 0) {
                    inputContext.inputMap |= ControllerPacket.DOWN_FLAG;
                }
                else {
                    inputContext.inputMap &= ~ControllerPacket.DOWN_FLAG;
                }

                controller.sendControllerInputContext();
            }
        });

        return digitalPad;
    }

    private static DigitalButton createDigitalButton(
            final int elementId,
            final int keyShort,
            final int keyLong,
            final int layer,
            final String text,
            final int icon,
            final VirtualController controller,
            final Context context) {
        DigitalButton button = new DigitalButton(controller, elementId, layer, context);
        button.setText(text);
        button.setIcon(icon);

        button.addDigitalButtonListener(new DigitalButton.DigitalButtonListener() {
            @Override
            public void onClick() {
                VirtualController.ControllerInputContext inputContext =
                        controller.getControllerInputContext();
                inputContext.inputMap |= keyShort;

                controller.sendControllerInputContext();
            }

            @Override
            public void onLongClick() {
                VirtualController.ControllerInputContext inputContext =
                        controller.getControllerInputContext();
                inputContext.inputMap |= keyLong;

                controller.sendControllerInputContext();
            }

            @Override
            public void onRelease() {
                VirtualController.ControllerInputContext inputContext =
                        controller.getControllerInputContext();
                inputContext.inputMap &= ~keyShort;
                inputContext.inputMap &= ~keyLong;

                controller.sendControllerInputContext();
            }
        });

        return button;
    }

    private static DigitalButton createLeftTrigger(
            final int layer,
            final String text,
            final int icon,
            final VirtualController controller,
            final Context context) {
        LeftTrigger button = new LeftTrigger(controller, layer, context);
        button.setText(text);
        button.setIcon(icon);
        return button;
    }

    private static DigitalButton createRightTrigger(
            final int layer,
            final String text,
            final int icon,
            final VirtualController controller,
            final Context context) {
        RightTrigger button = new RightTrigger(controller, layer, context);
        button.setText(text);
        button.setIcon(icon);
        return button;
    }

    private static AnalogStick createLeftStick(
            final VirtualController controller,
            final Context context) {
        return new LeftAnalogStick(controller, context);
    }

    private static AnalogStick createRightStick(
            final VirtualController controller,
            final Context context) {
        return new RightAnalogStick(controller, context);
    }


    private static final int TRIGGER_L_BASE_X = 1;
    private static final int TRIGGER_R_BASE_X = 92;
    private static final int TRIGGER_DISTANCE = 23;
    private static final int TRIGGER_BASE_Y = 31;
    private static final int TRIGGER_WIDTH = 12;
    private static final int TRIGGER_HEIGHT = 9;

    // Face buttons are defined based on the Y button (button number 9)
    private static final int BUTTON_BASE_X = 106;
    private static final int BUTTON_BASE_Y = 1;
    private static final int BUTTON_SIZE = 10;

    private static final int DPAD_BASE_X = 4;
    private static final int DPAD_BASE_Y = 41;
    private static final int DPAD_SIZE = 30;

    private static final int ANALOG_L_BASE_X = 6;
    private static final int ANALOG_L_BASE_Y = 4;
    private static final int ANALOG_R_BASE_X = 98;
    private static final int ANALOG_R_BASE_Y = 42;
    private static final int ANALOG_SIZE = 26;

    private static final int L3_R3_BASE_Y = 60;

    private static final int START_X = 83;
    private static final int BACK_X = 34;
    private static final int START_BACK_Y = 64;
    private static final int START_BACK_WIDTH = 12;
    private static final int START_BACK_HEIGHT = 7;

    // Make the Guide Menu be in the center of START and BACK menu
    private static final int GUIDE_X = START_X-BACK_X;
    private static final int GUIDE_Y = START_BACK_Y;

    public static void createDefaultLayout(final VirtualController controller, final Context context) {

        DisplayMetrics screen = context.getResources().getDisplayMetrics();
        PreferenceConfiguration config = PreferenceConfiguration.readPreferences(context);

        // Displace controls on the right by this amount of pixels to account for different aspect ratios
        int rightDisplacement = screen.widthPixels - screen.heightPixels * 16 / 9;

        int height = screen.heightPixels;

        // NOTE: Some of these getPercent() expressions seem like they can be combined
        // into a single call. Due to floating point rounding, this isn't actually possible.

        if (!config.onlyL3R3)
        {
            controller.addElement(createDigitalPad(controller, context),
                    screenScale(DPAD_BASE_X, height),
                    screenScale(DPAD_BASE_Y, height),
                    screenScale(DPAD_SIZE, height),
                    screenScale(DPAD_SIZE, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_A,
                    !config.flipFaceButtons ? ControllerPacket.A_FLAG : ControllerPacket.B_FLAG, 0, 1,
                    !config.flipFaceButtons ? "A" : "B", -1, controller, context),
                    screenScale(BUTTON_BASE_X, height) + rightDisplacement,
                    screenScale(BUTTON_BASE_Y + 2 * BUTTON_SIZE, height),
                    screenScale(BUTTON_SIZE, height),
                    screenScale(BUTTON_SIZE, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_B,
                    config.flipFaceButtons ? ControllerPacket.A_FLAG : ControllerPacket.B_FLAG, 0, 1,
                    config.flipFaceButtons ? "A" : "B", -1, controller, context),
                    screenScale(BUTTON_BASE_X + BUTTON_SIZE, height) + rightDisplacement,
                    screenScale(BUTTON_BASE_Y + BUTTON_SIZE, height),
                    screenScale(BUTTON_SIZE, height),
                    screenScale(BUTTON_SIZE, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_X,
                    !config.flipFaceButtons ? ControllerPacket.X_FLAG : ControllerPacket.Y_FLAG, 0, 1,
                    !config.flipFaceButtons ? "X" : "Y", -1, controller, context),
                    screenScale(BUTTON_BASE_X - BUTTON_SIZE, height) + rightDisplacement,
                    screenScale(BUTTON_BASE_Y + BUTTON_SIZE, height),
                    screenScale(BUTTON_SIZE, height),
                    screenScale(BUTTON_SIZE, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_Y,
                    config.flipFaceButtons ? ControllerPacket.X_FLAG : ControllerPacket.Y_FLAG, 0, 1,
                    config.flipFaceButtons ? "X" : "Y", -1, controller, context),
                    screenScale(BUTTON_BASE_X, height) + rightDisplacement,
                    screenScale(BUTTON_BASE_Y, height),
                    screenScale(BUTTON_SIZE, height),
                    screenScale(BUTTON_SIZE, height)
            );

            controller.addElement(createLeftTrigger(
                    1, "LT", -1, controller, context),
                    screenScale(TRIGGER_L_BASE_X, height),
                    screenScale(TRIGGER_BASE_Y, height),
                    screenScale(TRIGGER_WIDTH, height),
                    screenScale(TRIGGER_HEIGHT, height)
            );

            controller.addElement(createRightTrigger(
                    1, "RT", -1, controller, context),
                    screenScale(TRIGGER_R_BASE_X + TRIGGER_DISTANCE, height) + rightDisplacement,
                    screenScale(TRIGGER_BASE_Y, height),
                    screenScale(TRIGGER_WIDTH, height),
                    screenScale(TRIGGER_HEIGHT, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_LB,
                    ControllerPacket.LB_FLAG, 0, 1, "LB", -1, controller, context),
                    screenScale(TRIGGER_L_BASE_X + TRIGGER_DISTANCE, height),
                    screenScale(TRIGGER_BASE_Y, height),
                    screenScale(TRIGGER_WIDTH, height),
                    screenScale(TRIGGER_HEIGHT, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_RB,
                    ControllerPacket.RB_FLAG, 0, 1, "RB", -1, controller, context),
                    screenScale(TRIGGER_R_BASE_X, height) + rightDisplacement,
                    screenScale(TRIGGER_BASE_Y, height),
                    screenScale(TRIGGER_WIDTH, height),
                    screenScale(TRIGGER_HEIGHT, height)
            );

            controller.addElement(createLeftStick(controller, context),
                    screenScale(ANALOG_L_BASE_X, height),
                    screenScale(ANALOG_L_BASE_Y, height),
                    screenScale(ANALOG_SIZE, height),
                    screenScale(ANALOG_SIZE, height)
            );

            controller.addElement(createRightStick(controller, context),
                    screenScale(ANALOG_R_BASE_X, height) + rightDisplacement,
                    screenScale(ANALOG_R_BASE_Y, height),
                    screenScale(ANALOG_SIZE, height),
                    screenScale(ANALOG_SIZE, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_BACK,
                    ControllerPacket.BACK_FLAG, 0, 2, "BACK", -1, controller, context),
                    screenScale(BACK_X, height),
                    screenScale(START_BACK_Y, height),
                    screenScale(START_BACK_WIDTH, height),
                    screenScale(START_BACK_HEIGHT, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_START,
                    ControllerPacket.PLAY_FLAG, 0, 3, "START", -1, controller, context),
                    screenScale(START_X, height) + rightDisplacement,
                    screenScale(START_BACK_Y, height),
                    screenScale(START_BACK_WIDTH, height),
                    screenScale(START_BACK_HEIGHT, height)
            );
        }
        else {
            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_LSB,
                    ControllerPacket.LS_CLK_FLAG, 0, 1, "L3", -1, controller, context),
                    screenScale(TRIGGER_L_BASE_X, height),
                    screenScale(L3_R3_BASE_Y, height),
                    screenScale(TRIGGER_WIDTH, height),
                    screenScale(TRIGGER_HEIGHT, height)
            );

            controller.addElement(createDigitalButton(
                    VirtualControllerElement.EID_RSB,
                    ControllerPacket.RS_CLK_FLAG, 0, 1, "R3", -1, controller, context),
                    screenScale(TRIGGER_R_BASE_X + TRIGGER_DISTANCE, height) + rightDisplacement,
                    screenScale(L3_R3_BASE_Y, height),
                    screenScale(TRIGGER_WIDTH, height),
                    screenScale(TRIGGER_HEIGHT, height)
            );
        }

        if(config.showGuideButton){
            controller.addElement(createDigitalButton(VirtualControllerElement.EID_GDB,
                            ControllerPacket.SPECIAL_BUTTON_FLAG, 0, 1, "GUIDE", -1, controller, context),
                    screenScale(GUIDE_X, height)+ rightDisplacement,
                    screenScale(GUIDE_Y, height),
                    screenScale(START_BACK_WIDTH, height),
                    screenScale(START_BACK_HEIGHT, height)
            );
        }

        controller.setOpacity(config.oscOpacity);
    }

    private static SharedPreferences prefs(Context context) {
        return ProfileStore.prefs(context);
    }

    public static ControlTheme getTheme(Context context) {
        return ControlTheme.byId(prefs(context).getString(THEME_KEY, ControlTheme.GAMEHUB.id));
    }

    public static void saveTheme(Context context, ControlTheme theme) {
        prefs(context).edit().putString(THEME_KEY, theme.id).apply();
    }

    /** True if the stock gamepad elements should be part of the active profile's layout. */
    public static boolean usesGamepadBase(Context context) {
        return !LayoutPresets.BASE_NONE.equals(prefs(context).getString(BASE_KEY, LayoutPresets.BASE_GAMEPAD));
    }

    public static void saveProfile(final VirtualController controller,
                                   final Context context) {
        SharedPreferences.Editor prefEditor = prefs(context).edit();

        for (VirtualControllerElement element : controller.getElements()) {
            String prefKey = "" + element.elementId;
            try {
                prefEditor.putString(prefKey, element.getConfiguration().toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }

            if (element.getStyle().isDefault()) {
                prefEditor.remove(STYLE_PREFIX + element.elementId);
            }
            else {
                prefEditor.putString(STYLE_PREFIX + element.elementId, element.getStyle().toJson());
            }
        }

        prefEditor.apply();
    }

    /** Persists the appearance of a single button right away. */
    public static void saveStyle(Context context, int elementId, ControlStyle style) {
        SharedPreferences.Editor e = prefs(context).edit();
        if (style.isDefault()) {
            e.remove(STYLE_PREFIX + elementId);
        }
        else {
            e.putString(STYLE_PREFIX + elementId, style.toJson());
        }
        e.apply();
    }

    public static void loadFromPreferences(final VirtualController controller, final Context context) {
        SharedPreferences pref = prefs(context);
        ControlTheme theme = getTheme(context);
        controller.setThemeInternal(theme);

        for (VirtualControllerElement element : controller.getElements()) {
            String prefKey = "" + element.elementId;

            element.setTheme(theme);
            element.setStyle(ControlStyle.fromJson(pref.getString(STYLE_PREFIX + element.elementId, null)));

            String jsonConfig = pref.getString(prefKey, null);
            if (jsonConfig != null) {
                try {
                    element.loadConfiguration(new JSONObject(jsonConfig));
                } catch (JSONException e) {
                    e.printStackTrace();

                    // Remove the corrupt element from the preferences
                    pref.edit().remove(prefKey).apply();
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------
    // User-added buttons (keyboard / mouse bindings, gamepad buttons, WASD joystick)
    // ---------------------------------------------------------------------------------

    private static VirtualControllerElement buildCustomElement(
            VirtualController controller, Context context, JSONObject o) throws JSONException {
        int id = o.getInt("id");
        String type = o.optString("type", TYPE_KEY);

        if (TYPE_WASD.equals(type)) {
            return new WasdJoystick(controller, context, id);
        }
        if (TYPE_PAD.equals(type)) {
            int flag = o.has("pad") ? o.getInt("pad") : o.optInt("code");
            String label = o.optString("label", "");
            if (label.isEmpty()) {
                for (KeyCatalog.Entry e : KeyCatalog.PAD_BUTTONS) {
                    if (e.code == flag) {
                        label = e.label;
                    }
                }
            }
            return createDigitalButton(id, flag, 0, 1, label, -1, controller, context);
        }
        return new KeyButton(controller, id, Binding.fromJson(o), context);
    }

    private static int[] defaultSize(String type, int screenH) {
        if (TYPE_WASD.equals(type)) {
            int s = (int) (screenH * 0.42f);
            return new int[]{s, s};
        }
        int s = (int) (screenH * 0.14f);
        return new int[]{s, s};
    }

    public static void loadCustomElements(final VirtualController controller, final Context context) {
        SharedPreferences pref = prefs(context);
        DisplayMetrics screen = context.getResources().getDisplayMetrics();

        JSONArray array = readCustomArray(pref);
        for (int i = 0; i < array.length(); i++) {
            try {
                JSONObject o = array.getJSONObject(i);
                VirtualControllerElement element = buildCustomElement(controller, context, o);

                // Buttons saved by the first version stored their label next to the key code
                if (o.has("label") && pref.getString(STYLE_PREFIX + o.getInt("id"), null) == null
                        && TYPE_KEY.equals(o.optString("type", TYPE_KEY))) {
                    ControlStyle style = new ControlStyle();
                    style.label = o.getString("label");
                    pref.edit().putString(STYLE_PREFIX + o.getInt("id"), style.toJson()).apply();
                }

                int[] size = defaultSize(o.optString("type", TYPE_KEY), screen.heightPixels);
                // Default position; the real one is applied by loadFromPreferences()
                controller.addElement(element,
                        screen.widthPixels / 2 - size[0] / 2,
                        screen.heightPixels / 2 - size[1] / 2,
                        size[0], size[1]);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private static JSONArray readCustomArray(SharedPreferences pref) {
        try {
            return new JSONArray(pref.getString(CUSTOM_ELEMENTS_KEY, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    /** Adds a new user button to the active profile and to the screen. Returns the new element. */
    public static VirtualControllerElement addCustomElement(VirtualController controller, Context context,
                                                            String type, Binding binding, int padFlag) {
        SharedPreferences pref = prefs(context);
        DisplayMetrics screen = context.getResources().getDisplayMetrics();

        int id = pref.getInt(CUSTOM_NEXT_ID_KEY, VirtualControllerElement.EID_CUSTOM_BASE);
        JSONObject o = new JSONObject();

        try {
            o.put("id", id);
            o.put("type", type);
            if (binding != null) {
                JSONObject b = binding.toJson();
                o.put("keys", b.getJSONArray("keys"));
                o.put("mouse", b.getJSONArray("mouse"));
            }
            if (TYPE_PAD.equals(type)) {
                o.put("pad", padFlag);
            }

            JSONArray array = readCustomArray(pref);
            array.put(o);
            pref.edit()
                    .putString(CUSTOM_ELEMENTS_KEY, array.toString())
                    .putInt(CUSTOM_NEXT_ID_KEY, id + 1)
                    .apply();

            VirtualControllerElement element = buildCustomElement(controller, context, o);
            int[] size = defaultSize(type, screen.heightPixels);
            controller.addElement(element,
                    screen.widthPixels / 2 - size[0] / 2,
                    screen.heightPixels / 2 - size[1] / 2,
                    size[0], size[1]);
            controller.styleNewElement(element);
            return element;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    /** Stores a new binding for an existing key button. */
    public static void saveBinding(Context context, int elementId, Binding binding) {
        SharedPreferences pref = prefs(context);
        JSONArray array = readCustomArray(pref);
        try {
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                if (o.getInt("id") == elementId) {
                    JSONObject b = binding.toJson();
                    o.put("keys", b.getJSONArray("keys"));
                    o.put("mouse", b.getJSONArray("mouse"));
                    o.remove("code");
                }
            }
            pref.edit().putString(CUSTOM_ELEMENTS_KEY, array.toString()).apply();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static boolean hasJoystick(Context context) {
        JSONArray array = readCustomArray(prefs(context));
        for (int i = 0; i < array.length(); i++) {
            if (TYPE_WASD.equals(array.optJSONObject(i).optString("type"))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Called when the user deletes a button: custom buttons are forgotten completely,
     * default buttons are remembered as hidden.
     */
    public static void onElementDeleted(Context context, int elementId) {
        SharedPreferences pref = prefs(context);
        SharedPreferences.Editor editor = pref.edit();
        editor.remove("" + elementId);
        editor.remove(STYLE_PREFIX + elementId);

        if (elementId >= VirtualControllerElement.EID_CUSTOM_BASE) {
            JSONArray old = readCustomArray(pref);
            JSONArray kept = new JSONArray();
            for (int i = 0; i < old.length(); i++) {
                try {
                    JSONObject o = old.getJSONObject(i);
                    if (o.getInt("id") != elementId) {
                        kept.put(o);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            editor.putString(CUSTOM_ELEMENTS_KEY, kept.toString());
        }
        else {
            Set<String> deleted = new HashSet<>(pref.getStringSet(DELETED_ELEMENTS_KEY, new HashSet<String>()));
            deleted.add("" + elementId);
            editor.putStringSet(DELETED_ELEMENTS_KEY, deleted);
        }

        editor.apply();
    }

    public static void removeDeletedElements(final VirtualController controller, final Context context) {
        Set<String> deleted = prefs(context).getStringSet(DELETED_ELEMENTS_KEY, null);
        if (deleted == null || deleted.isEmpty()) {
            return;
        }

        List<VirtualControllerElement> toRemove = new ArrayList<>();
        for (VirtualControllerElement element : controller.getElements()) {
            if (deleted.contains("" + element.elementId)) {
                toRemove.add(element);
            }
        }
        for (VirtualControllerElement element : toRemove) {
            controller.removeElement(element);
        }
    }
}
