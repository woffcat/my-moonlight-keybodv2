package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Keeps the list of control profiles (layout + theme + buttons) and remembers which one is used
 * by default and for each individual game.
 *
 * Every profile owns one SharedPreferences file. The "default" profile keeps using the original
 * "OSC" file so layouts saved by earlier versions are preserved.
 */
public final class ProfileStore {
    public static final String DEFAULT_ID = "default";

    private static final String REGISTRY = "OSC_PROFILES";
    private static final String KEY_PROFILES = "profiles";
    private static final String KEY_DEFAULT_NAME = "default_name";
    private static final String KEY_ACTIVE = "active";
    private static final String KEY_LOW_PERF = "low_perf";
    private static final String GAME_PREFIX = "game_";

    public static final class Profile {
        public final String id;
        public String name;

        Profile(String id, String name) {
            this.id = id;
            this.name = name;
        }
    }

    private ProfileStore() {
    }

    private static SharedPreferences registry(Context c) {
        return c.getApplicationContext().getSharedPreferences(REGISTRY, Context.MODE_PRIVATE);
    }

    public static String prefsName(String id) {
        return DEFAULT_ID.equals(id) ? VirtualControllerConfigurationLoader.OSC_PREFERENCE : "OSC_P_" + id;
    }

    public static SharedPreferences prefs(Context c, String id) {
        return c.getApplicationContext().getSharedPreferences(prefsName(id), Context.MODE_PRIVATE);
    }

    /** Preferences of the profile that is currently in use. */
    public static SharedPreferences prefs(Context c) {
        return prefs(c, activeId(c));
    }

    public static List<Profile> list(Context c) {
        SharedPreferences r = registry(c);
        List<Profile> out = new ArrayList<>();
        out.add(new Profile(DEFAULT_ID, r.getString(KEY_DEFAULT_NAME, "Default")));
        try {
            JSONArray a = new JSONArray(r.getString(KEY_PROFILES, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Profile(o.getString("id"), o.getString("name")));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return out;
    }

    private static void writeList(Context c, List<Profile> all) {
        JSONArray a = new JSONArray();
        String defaultName = "Default";
        for (Profile p : all) {
            if (DEFAULT_ID.equals(p.id)) {
                defaultName = p.name;
                continue;
            }
            try {
                JSONObject o = new JSONObject();
                o.put("id", p.id);
                o.put("name", p.name);
                a.put(o);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        registry(c).edit().putString(KEY_PROFILES, a.toString()).putString(KEY_DEFAULT_NAME, defaultName).apply();
    }

    public static Profile find(Context c, String id) {
        for (Profile p : list(c)) {
            if (p.id.equals(id)) {
                return p;
            }
        }
        return null;
    }

    public static String activeId(Context c) {
        String id = registry(c).getString(KEY_ACTIVE, DEFAULT_ID);
        return find(c, id) != null ? id : DEFAULT_ID;
    }

    public static void setActive(Context c, String id) {
        registry(c).edit().putString(KEY_ACTIVE, id).apply();
    }

    public static String activeName(Context c) {
        Profile p = find(c, activeId(c));
        return p != null ? p.name : "Default";
    }

    /** Creates a new profile. If copyFromId is not null the layout and theme are copied from it. */
    public static Profile create(Context c, String name, String copyFromId) {
        String id = "p" + Long.toString(System.currentTimeMillis(), 36) + Integer.toString(new Random().nextInt(1296), 36);
        Profile p = new Profile(id, name);
        List<Profile> all = list(c);
        all.add(p);
        writeList(c, all);

        if (copyFromId != null) {
            copyPrefs(prefs(c, copyFromId), prefs(c, id));
        }
        return p;
    }

    private static void copyPrefs(SharedPreferences from, SharedPreferences to) {
        SharedPreferences.Editor e = to.edit();
        e.clear();
        for (Map.Entry<String, ?> entry : from.getAll().entrySet()) {
            Object v = entry.getValue();
            String k = entry.getKey();
            if (v instanceof String) {
                e.putString(k, (String) v);
            }
            else if (v instanceof Integer) {
                e.putInt(k, (Integer) v);
            }
            else if (v instanceof Boolean) {
                e.putBoolean(k, (Boolean) v);
            }
            else if (v instanceof Long) {
                e.putLong(k, (Long) v);
            }
            else if (v instanceof Float) {
                e.putFloat(k, (Float) v);
            }
            else if (v instanceof Set) {
                Set<String> copy = new HashSet<>();
                for (Object o : (Set<?>) v) {
                    copy.add(String.valueOf(o));
                }
                e.putStringSet(k, copy);
            }
        }
        e.apply();
    }

    public static void rename(Context c, String id, String newName) {
        List<Profile> all = list(c);
        for (Profile p : all) {
            if (p.id.equals(id)) {
                p.name = newName;
            }
        }
        writeList(c, all);
    }

    /** Deletes a profile. The default profile cannot be deleted, only reset. */
    public static void delete(Context c, String id) {
        if (DEFAULT_ID.equals(id)) {
            prefs(c, id).edit().clear().apply();
            return;
        }

        List<Profile> all = list(c);
        List<Profile> kept = new ArrayList<>();
        for (Profile p : all) {
            if (!p.id.equals(id)) {
                kept.add(p);
            }
        }
        writeList(c, kept);
        prefs(c, id).edit().clear().apply();

        SharedPreferences r = registry(c);
        SharedPreferences.Editor e = r.edit();
        if (id.equals(r.getString(KEY_ACTIVE, DEFAULT_ID))) {
            e.putString(KEY_ACTIVE, DEFAULT_ID);
        }
        for (String key : new ArrayList<>(r.getAll().keySet())) {
            if (key.startsWith(GAME_PREFIX) && id.equals(r.getString(key, null))) {
                e.remove(key);
            }
        }
        e.apply();
    }

    // ---- per game assignment ----

    public static String gameKey(String pcUuid, int appId) {
        return (pcUuid != null ? pcUuid : "pc") + ":" + appId;
    }

    public static String gameProfile(Context c, String gameKey) {
        if (gameKey == null) {
            return null;
        }
        String id = registry(c).getString(GAME_PREFIX + gameKey, null);
        return (id != null && find(c, id) != null) ? id : null;
    }

    /** Pass null as profileId to go back to the default profile for this game. */
    public static void setGameProfile(Context c, String gameKey, String profileId) {
        SharedPreferences.Editor e = registry(c).edit();
        if (profileId == null) {
            e.remove(GAME_PREFIX + gameKey);
        }
        else {
            e.putString(GAME_PREFIX + gameKey, profileId);
        }
        e.apply();
    }

    /** Called when a stream starts: picks the profile assigned to this game, if any. */
    public static void activateForGame(Context c, String gameKey) {
        String id = gameProfile(c, gameKey);
        if (id != null) {
            setActive(c, id);
        }
        else {
            // Games without their own assignment use the profile chosen as the general default
            // (stored separately so that a per-game switch does not change it).
            String general = registry(c).getString("general", DEFAULT_ID);
            setActive(c, find(c, general) != null ? general : DEFAULT_ID);
        }
    }

    public static void setGeneralDefault(Context c, String id) {
        registry(c).edit().putString("general", id).putString(KEY_ACTIVE, id).apply();
    }

    public static String generalDefault(Context c) {
        String id = registry(c).getString("general", DEFAULT_ID);
        return find(c, id) != null ? id : DEFAULT_ID;
    }

    // ---- global performance switch ----

    public static boolean isLowPerformance(Context c) {
        return registry(c).getBoolean(KEY_LOW_PERF, false);
    }

    public static void setLowPerformance(Context c, boolean value) {
        registry(c).edit().putBoolean(KEY_LOW_PERF, value).apply();
    }
}
