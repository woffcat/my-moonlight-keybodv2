package com.limelight.binding.input.virtual_controller;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * What a virtual button does when pressed: any number of keyboard keys and mouse inputs
 * that are pressed together (e.g. D + S, or Ctrl + Left click).
 */
public final class Binding {
    // These values match MouseButtonPacket.BUTTON_*
    public static final int MOUSE_LEFT = 1;
    public static final int MOUSE_MIDDLE = 2;
    public static final int MOUSE_RIGHT = 3;
    public static final int MOUSE_X1 = 4;
    public static final int MOUSE_X2 = 5;
    // Pseudo buttons for the scroll wheel
    public static final int WHEEL_UP = 100;
    public static final int WHEEL_DOWN = 101;

    public int[] keys = new int[0];
    public int[] mouse = new int[0];

    public boolean isEmpty() {
        return keys.length == 0 && mouse.length == 0;
    }

    public Binding copy() {
        Binding b = new Binding();
        b.keys = keys.clone();
        b.mouse = mouse.clone();
        return b;
    }

    public static String mouseName(int code) {
        switch (code) {
            case MOUSE_LEFT: return "LMB";
            case MOUSE_RIGHT: return "RMB";
            case MOUSE_MIDDLE: return "MMB";
            case MOUSE_X1: return "M4";
            case MOUSE_X2: return "M5";
            case WHEEL_UP: return "Wheel\u2191";
            case WHEEL_DOWN: return "Wheel\u2193";
            default: return "?";
        }
    }

    public static String keyName(int androidKeyCode) {
        for (KeyCatalog.Entry e : KeyCatalog.KEYS) {
            if (e.code == androidKeyCode) {
                return e.label;
            }
        }
        return "?";
    }

    /** Short human readable text such as "D+S" or "Ctrl+LMB". */
    public String describe() {
        StringBuilder sb = new StringBuilder();
        for (int k : keys) {
            if (sb.length() > 0) sb.append('+');
            sb.append(keyName(k));
        }
        for (int m : mouse) {
            if (sb.length() > 0) sb.append('+');
            sb.append(mouseName(m));
        }
        return sb.toString();
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        JSONArray k = new JSONArray();
        for (int v : keys) k.put(v);
        JSONArray m = new JSONArray();
        for (int v : mouse) m.put(v);
        o.put("keys", k);
        o.put("mouse", m);
        return o;
    }

    public static Binding fromJson(JSONObject o) {
        Binding b = new Binding();
        JSONArray k = o.optJSONArray("keys");
        if (k != null) {
            b.keys = new int[k.length()];
            for (int i = 0; i < b.keys.length; i++) b.keys[i] = k.optInt(i);
        }
        else if (o.has("code")) {
            // Format written by the first version of the on-screen keyboard buttons
            b.keys = new int[]{o.optInt("code")};
        }
        JSONArray m = o.optJSONArray("mouse");
        if (m != null) {
            b.mouse = new int[m.length()];
            for (int i = 0; i < b.mouse.length; i++) b.mouse[i] = m.optInt(i);
        }
        return b;
    }

    public static Binding ofKeys(int... keys) {
        Binding b = new Binding();
        b.keys = keys;
        return b;
    }

    public static Binding ofMouse(int... mouse) {
        Binding b = new Binding();
        b.mouse = mouse;
        return b;
    }
}
