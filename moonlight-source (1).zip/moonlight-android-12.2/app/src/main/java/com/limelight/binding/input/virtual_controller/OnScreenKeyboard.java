package com.limelight.binding.input.virtual_controller;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

/**
 * A tap-on-screen keyboard that sends real key down/up events to the host.
 * Shift / Ctrl / Alt / Win are sticky toggles so they can be combined with other keys.
 */
public class OnScreenKeyboard extends LinearLayout {
    private static final int KEY_NORMAL = 0xCC303030;
    private static final int KEY_PRESSED = 0xFF2F6BFF;
    private static final int KEY_STICKY_ON = 0xFFE08A00;

    private final VirtualController controller;

    // {label, android keycode, weight*10, sticky(0/1)}
    private static Object[] k(String label, int code, float weight, boolean sticky) {
        return new Object[]{label, code, weight, sticky};
    }

    private static Object[] k(String label, int code) {
        return k(label, code, 1f, false);
    }

    public OnScreenKeyboard(Context context, VirtualController controller) {
        super(context);
        this.controller = controller;

        setOrientation(VERTICAL);
        setBackgroundColor(0x99000000);
        setClickable(true); // swallow touches in the gaps so they don't reach the stream
        setPadding(4, 4, 4, 4);

        // Row 1: Esc + F-keys
        Object[][] row1 = new Object[13][];
        row1[0] = k("Esc", KeyEvent.KEYCODE_ESCAPE);
        for (int i = 0; i < 12; i++) {
            row1[i + 1] = k("F" + (i + 1), KeyEvent.KEYCODE_F1 + i);
        }
        addRow(row1);

        // Row 2: numbers
        Object[][] row2 = new Object[12][];
        row2[0] = k("`", KeyEvent.KEYCODE_GRAVE);
        for (int i = 1; i <= 9; i++) {
            row2[i] = k(String.valueOf(i), KeyEvent.KEYCODE_0 + i);
        }
        row2[10] = k("0", KeyEvent.KEYCODE_0);
        row2[11] = k("Bksp", KeyEvent.KEYCODE_DEL, 2f, false);
        addRow(row2);

        // Row 3: QWERTY
        addRow(buildLetterRow(new String[]{"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"},
                new int[]{KeyEvent.KEYCODE_Q, KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_E, KeyEvent.KEYCODE_R,
                        KeyEvent.KEYCODE_T, KeyEvent.KEYCODE_Y, KeyEvent.KEYCODE_U, KeyEvent.KEYCODE_I,
                        KeyEvent.KEYCODE_O, KeyEvent.KEYCODE_P},
                k("Tab", KeyEvent.KEYCODE_TAB, 1.5f, false),
                k("[", KeyEvent.KEYCODE_LEFT_BRACKET),
                k("]", KeyEvent.KEYCODE_RIGHT_BRACKET)));

        // Row 4: ASDF
        addRow(buildLetterRow(new String[]{"A", "S", "D", "F", "G", "H", "J", "K", "L", ";"},
                new int[]{KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_F,
                        KeyEvent.KEYCODE_G, KeyEvent.KEYCODE_H, KeyEvent.KEYCODE_J, KeyEvent.KEYCODE_K,
                        KeyEvent.KEYCODE_L, KeyEvent.KEYCODE_SEMICOLON},
                k("Caps", KeyEvent.KEYCODE_CAPS_LOCK, 1.7f, false),
                k("'", KeyEvent.KEYCODE_APOSTROPHE),
                k("Enter", KeyEvent.KEYCODE_ENTER, 2f, false)));

        // Row 5: ZXCV
        addRow(buildLetterRow(new String[]{"Z", "X", "C", "V", "B", "N", "M", ",", ".", "/"},
                new int[]{KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_C, KeyEvent.KEYCODE_V,
                        KeyEvent.KEYCODE_B, KeyEvent.KEYCODE_N, KeyEvent.KEYCODE_M, KeyEvent.KEYCODE_COMMA,
                        KeyEvent.KEYCODE_PERIOD, KeyEvent.KEYCODE_SLASH},
                k("Shift", KeyEvent.KEYCODE_SHIFT_LEFT, 2.2f, true),
                k("\u2191", KeyEvent.KEYCODE_DPAD_UP, 1f, false),
                k("Del", KeyEvent.KEYCODE_FORWARD_DEL, 1f, false)));

        // Row 6: modifiers, space, arrows
        addRow(new Object[][]{
                k("Ctrl", KeyEvent.KEYCODE_CTRL_LEFT, 1.5f, true),
                k("Win", KeyEvent.KEYCODE_META_LEFT, 1.2f, true),
                k("Alt", KeyEvent.KEYCODE_ALT_LEFT, 1.2f, true),
                k("Space", KeyEvent.KEYCODE_SPACE, 6f, false),
                k("\u2190", KeyEvent.KEYCODE_DPAD_LEFT),
                k("\u2193", KeyEvent.KEYCODE_DPAD_DOWN),
                k("\u2192", KeyEvent.KEYCODE_DPAD_RIGHT)
        });
    }

    private Object[][] buildLetterRow(String[] labels, int[] codes, Object[] first, Object[] extraA, Object[] extraB) {
        Object[][] row = new Object[labels.length + 3][];
        row[0] = first;
        for (int i = 0; i < labels.length; i++) {
            row[i + 1] = k(labels[i], codes[i]);
        }
        row[labels.length + 1] = extraA;
        row[labels.length + 2] = extraB;
        return row;
    }

    private void addRow(Object[][] keys) {
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(HORIZONTAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, 0, 1f);
        addView(row, rowParams);

        for (Object[] key : keys) {
            String label = (String) key[0];
            int code = (Integer) key[1];
            float weight = (Float) key[2];
            boolean sticky = (Boolean) key[3];
            row.addView(createKey(label, code, sticky),
                    new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT, weight));
        }
    }

    private static GradientDrawable roundRect(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(10f);
        d.setStroke(1, Color.argb(120, 255, 255, 255));
        return d;
    }

    private Button createKey(String label, final int code, final boolean sticky) {
        Button b = new Button(getContext());
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(11f);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinHeight(0);
        b.setMinimumWidth(0);
        b.setMinimumHeight(0);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(false);
        b.setTag(code);

        StateListDrawable states = new StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, roundRect(KEY_PRESSED));
        states.addState(new int[]{android.R.attr.state_selected}, roundRect(KEY_STICKY_ON));
        states.addState(new int[]{}, roundRect(KEY_NORMAL));
        b.setBackground(states);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LayoutParams.MATCH_PARENT);
        lp.setMargins(2, 2, 2, 2);
        b.setLayoutParams(lp);

        b.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        if (sticky) {
                            boolean on = !v.isSelected();
                            v.setSelected(on);
                            controller.sendKey(code, on);
                        } else {
                            v.setPressed(true);
                            controller.sendKey(code, true);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        if (!sticky) {
                            v.setPressed(false);
                            controller.sendKey(code, false);
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });

        return b;
    }

    /**
     * Release any sticky modifiers that are still held (called when the panel is hidden).
     */
    public void releaseAllModifiers() {
        releaseSelected(this);
    }

    private void releaseSelected(View v) {
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup g = (android.view.ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                releaseSelected(g.getChildAt(i));
            }
        } else if (v instanceof Button && v.isSelected()) {
            v.setSelected(false);
            Object tag = v.getTag();
            if (tag instanceof Integer) {
                controller.sendKey((Integer) tag, false);
            }
        }
    }
}
