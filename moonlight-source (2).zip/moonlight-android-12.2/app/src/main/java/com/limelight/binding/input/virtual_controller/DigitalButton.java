/**
 * Created by Karim Mreisi.
 */

package com.limelight.binding.input.virtual_controller;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * This is a digital button on screen element. It is used to get click and double click user input.
 */
public class DigitalButton extends VirtualControllerElement {

    /**
     * Listener interface to update registered observers.
     */
    public interface DigitalButtonListener {

        /**
         * onClick event will be fired on button click.
         */
        void onClick();

        /**
         * onLongClick event will be fired on button long click.
         */
        void onLongClick();

        /**
         * onRelease event will be fired on button unpress.
         */
        void onRelease();
    }

    private List<DigitalButtonListener> listeners = new ArrayList<>();
    private String text = "";
    private int icon = -1;
    private long timerLongClickTimeout = 3000;
    private final Runnable longClickRunnable = new Runnable() {
        @Override
        public void run() {
            onLongClickCallback();
        }
    };

    // Drawing state. Everything here is built once (size / style change), never per frame.
    private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint subTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path shapePath = new Path();
    private final Path iconStroke = new Path();
    private final Path iconFill = new Path();
    private final Paint iconStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean hasVectorIcon = false;
    // Toggle mode: true while the button is being held down by a previous tap
    private boolean latched = false;
    private float inset;
    private float strokePx;
    private float mainTextY;
    private float subTextY;
    private String mainText = "";
    private String subText = "";
    private boolean pathValid = false;

    private float pressAnim = 0f;
    private ValueAnimator pressAnimator;

    private int layer;
    private DigitalButton movingButton = null;

    boolean inRange(float x, float y) {
        return (this.getX() < x && this.getX() + this.getWidth() > x) &&
                (this.getY() < y && this.getY() + this.getHeight() > y);
    }

    public boolean checkMovement(float x, float y, DigitalButton movingButton) {
        // toggle buttons only react to taps, never to a finger sliding over them
        if (style.toggle) {
            return false;
        }

        // check if the movement happened in the same layer
        if (movingButton.layer != this.layer) {
            return false;
        }

        // save current pressed state
        boolean wasPressed = isPressed();

        // check if the movement directly happened on the button
        if ((this.movingButton == null || movingButton == this.movingButton)
                && this.inRange(x, y)) {
            // set button pressed state depending on moving button pressed state
            if (this.isPressed() != movingButton.isPressed()) {
                this.setPressed(movingButton.isPressed());
            }
        }
        // check if the movement is outside of the range and the movement button
        // is the saved moving button
        else if (movingButton == this.movingButton) {
            this.setPressed(false);
        }

        // check if a change occurred
        if (wasPressed != isPressed()) {
            if (isPressed()) {
                // is pressed set moving button and emit click event
                this.movingButton = movingButton;
                onClickCallback();
            } else {
                // no longer pressed reset moving button and emit release event
                this.movingButton = null;
                onReleaseCallback();
            }

            invalidate();

            return true;
        }

        return false;
    }

    private void checkMovementForAllButtons(float x, float y) {
        for (VirtualControllerElement element : virtualController.getElements()) {
            if (element != this && element instanceof DigitalButton) {
                ((DigitalButton) element).checkMovement(x, y, this);
            }
        }
    }

    public DigitalButton(VirtualController controller, int elementId, int layer, Context context) {
        super(controller, context, elementId);
        this.layer = layer;
    }

    public void addDigitalButtonListener(DigitalButtonListener listener) {
        listeners.add(listener);
    }

    public void setText(String text) {
        this.text = text;
        pathValid = false;
        invalidate();
    }

    public void setIcon(int id) {
        this.icon = id;
        invalidate();
    }

    @Override
    public boolean usesThemeRendering() {
        return true;
    }

    @Override
    public boolean supportsShapeAndIcon() {
        return true;
    }

    /** Text shown when the user did not choose a custom label. */
    public String getDefaultLabel() {
        return text;
    }

    @Override
    protected void onStyleChanged() {
        pathValid = false;
        if (!style.toggle && latched) {
            // Toggle mode was switched off while the button was being held
            releaseAll();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        pathValid = false;
        super.onSizeChanged(w, h, oldw, oldh);
    }

    private void rebuild() {
        final float w = getWidth();
        final float h = getHeight();
        final float density = getResources().getDisplayMetrics().density;

        strokePx = Math.max(0f, theme.strokeDp * density);
        boolean glow = theme.glow != 0 && !virtualController.isLowPerformance();
        inset = Math.max(strokePx, 1f) + (glow ? strokePx * 2f : 0f);

        ControlTheme.buildShape(shapePath, ControlTheme.resolveShape(style, theme),
                inset, inset, w - inset, h - inset);

        // Text content: an icon replaces the label unless the user typed an explicit label as well
        String label = style.label != null ? style.label : getDefaultLabel();
        boolean hasIcon = style.icon != null && !style.icon.isEmpty();
        float min = Math.min(w, h);

        final VectorIcons.Icon vectorIcon = VectorIcons.find(style.icon);
        hasVectorIcon = vectorIcon != null;

        if (hasVectorIcon) {
            // Real vector icon, with the label (if any) as a small caption underneath
            boolean both = style.label != null && !style.label.isEmpty();
            float iconSize = min * (both ? 0.42f : 0.54f);
            VectorIcons.build(vectorIcon, (w - iconSize) / 2f, both ? h * 0.15f : (h - iconSize) / 2f,
                    iconSize, iconStroke, iconFill);
            VectorIcons.setupPaints(iconStrokePaint, iconFillPaint, iconSize, 0xFFFFFFFF);
            mainText = "";
            subText = both ? style.label : "";
            subTextPaint.setTextSize(min * 0.20f);
            subTextPaint.setTextAlign(Paint.Align.CENTER);
            subTextY = h * 0.82f;
        }
        else if (hasIcon) {
            mainText = style.icon;
            boolean both = style.label != null && !style.label.isEmpty();
            subText = both ? style.label : "";
            float mainSize = min * (both ? 0.38f : 0.50f);
            textPaint.setTextSize(mainSize);
            textPaint.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            if (both) {
                mainTextY = h * 0.46f - (fm.ascent + fm.descent) / 2f;
                subTextPaint.setTextSize(min * 0.20f);
                subTextPaint.setTextAlign(Paint.Align.CENTER);
                subTextY = h * 0.78f;
            }
            else {
                mainTextY = h / 2f - (fm.ascent + fm.descent) / 2f;
            }
        }
        else {
            mainText = label;
            subText = "";
            float size = min * 0.30f;
            textPaint.setTextSize(size);
            textPaint.setTextAlign(Paint.Align.CENTER);
            float maxWidth = w * 0.78f;
            float measured = textPaint.measureText(mainText);
            if (measured > maxWidth && measured > 0) {
                textPaint.setTextSize(size * maxWidth / measured);
            }
            Paint.FontMetrics fm = textPaint.getFontMetrics();
            mainTextY = h / 2f - (fm.ascent + fm.descent) / 2f;
        }

        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(strokePx);
        glowPaint.setStyle(Paint.Style.STROKE);
        glowPaint.setStrokeWidth(strokePx * 3f);
        fillPaint.setStyle(Paint.Style.FILL);
        textPaint.setFakeBoldText(!hasIcon);
        subTextPaint.setFakeBoldText(true);

        pathValid = true;
    }

    private int accentColor() {
        if (style.color != 0) {
            return 0xFF000000 | style.color;
        }
        if (theme.faceColors) {
            int face = ControlTheme.faceColor(elementId);
            if (face != 0) {
                return face;
            }
        }
        return 0;
    }

    @Override
    protected void onElementDraw(Canvas canvas) {
        if (!pathValid) {
            rebuild();
        }

        final boolean pressed = isPressed();
        final boolean configuring = virtualController.getControllerMode() != VirtualController.ControllerMode.Active;
        final int accent = accentColor();

        int fill;
        int stroke;
        int textColor;
        if (accent != 0) {
            fill = pressed ? ((0xB3 << 24) | (accent & 0xFFFFFF)) : ((0x4D << 24) | (accent & 0xFFFFFF));
            stroke = accent;
            textColor = pressed ? 0xFFFFFFFF : accent;
            if (theme.faceColors) {
                textColor = 0xFFFFFFFF;
            }
        }
        else {
            fill = pressed ? theme.fillPressed : theme.fill;
            stroke = pressed ? theme.strokePressed : theme.stroke;
            textColor = theme.text;
        }

        // While arranging buttons keep the red / magenta outline so it is obvious what mode is active
        float strokeWidth = strokePx;
        if (configuring) {
            stroke = getDefaultColor();
            strokeWidth = Math.max(strokePx, getDefaultStrokeWidth());
        }

        final boolean animate = pressAnim > 0f;
        if (animate) {
            float scale = 1f - 0.08f * pressAnim;
            canvas.save();
            canvas.scale(scale, scale, getWidth() / 2f, getHeight() / 2f);
        }

        fillPaint.setColor(fill);
        canvas.drawPath(shapePath, fillPaint);

        if (theme.glow != 0 && !virtualController.isLowPerformance() && !configuring) {
            int glowAlpha = pressed ? (theme.glow >>> 24) : (theme.glow >>> 24) / 3;
            glowPaint.setColor((glowAlpha << 24) | ((accent != 0 ? accent : theme.glow) & 0xFFFFFF));
            canvas.drawPath(shapePath, glowPaint);
        }

        if (strokeWidth > 0f && (stroke >>> 24) != 0) {
            strokePaint.setStrokeWidth(strokeWidth);
            strokePaint.setColor(stroke);
            canvas.drawPath(shapePath, strokePaint);
        }

        if (hasVectorIcon) {
            iconStrokePaint.setColor(textColor);
            iconFillPaint.setColor(textColor);
            canvas.drawPath(iconStroke, iconStrokePaint);
            canvas.drawPath(iconFill, iconFillPaint);
            if (!subText.isEmpty()) {
                subTextPaint.setColor(textColor);
                canvas.drawText(subText, getWidth() / 2f, subTextY, subTextPaint);
            }
        }
        else if (icon != -1 && style.icon.isEmpty()) {
            Drawable d = getResources().getDrawable(icon);
            d.setBounds(5, 5, getWidth() - 5, getHeight() - 5);
            d.draw(canvas);
        }
        else {
            textPaint.setColor(textColor);
            canvas.drawText(mainText, getWidth() / 2f, mainTextY, textPaint);
            if (!subText.isEmpty()) {
                subTextPaint.setColor(textColor);
                canvas.drawText(subText, getWidth() / 2f, subTextY, subTextPaint);
            }
        }

        if (animate) {
            canvas.restore();
        }
    }

    @Override
    public void setPressed(boolean pressed) {
        boolean changed = pressed != isPressed();
        super.setPressed(pressed);
        if (changed) {
            animatePress(pressed);
        }
    }

    private void animatePress(boolean pressed) {
        if (virtualController.isLowPerformance()) {
            if (pressAnimator != null) {
                pressAnimator.cancel();
            }
            pressAnim = 0f;
            return;
        }

        // One animator per button, reused for every press (no allocations while playing)
        if (pressAnimator == null) {
            pressAnimator = new ValueAnimator();
            pressAnimator.setDuration(70);
            pressAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {
                    pressAnim = (Float) animation.getAnimatedValue();
                    invalidate();
                }
            });
        }
        pressAnimator.cancel();
        pressAnimator.setFloatValues(pressAnim, pressed ? 1f : 0f);
        pressAnimator.start();
    }

    @Override
    public void releaseAll() {
        latched = false;
        if (isPressed()) {
            setPressed(false);
            onReleaseCallback();
        }
    }

    @Override
    public void onControllerModeChanged() {
        // Never leave a held (toggled) button down while arranging the layout
        releaseAll();
        super.onControllerModeChanged();
    }

    private void onClickCallback() {
        _DBG("clicked");
        // notify listeners
        for (DigitalButtonListener listener : listeners) {
            listener.onClick();
        }

        virtualController.getHandler().removeCallbacks(longClickRunnable);
        virtualController.getHandler().postDelayed(longClickRunnable, timerLongClickTimeout);
    }

    private void onLongClickCallback() {
        _DBG("long click");
        // notify listeners
        for (DigitalButtonListener listener : listeners) {
            listener.onLongClick();
        }
    }

    private void onReleaseCallback() {
        _DBG("released");
        // notify listeners
        for (DigitalButtonListener listener : listeners) {
            listener.onRelease();
        }

        // We may be called for a release without a prior click
        virtualController.getHandler().removeCallbacks(longClickRunnable);
    }

    @Override
    public boolean onElementTouchEvent(MotionEvent event) {
        // get masked (not specific to a pointer) action
        float x = getX() + event.getX();
        float y = getY() + event.getY();
        int action = event.getActionMasked();

        if (style.toggle) {
            // Toggle mode: a tap flips between "held down" and "released"
            if (action == MotionEvent.ACTION_DOWN) {
                movingButton = null;
                if (latched) {
                    latched = false;
                    setPressed(false);
                    onReleaseCallback();
                }
                else {
                    latched = true;
                    setPressed(true);
                    onClickCallback();
                    // A held button must not trigger the 3 second long-click action
                    virtualController.getHandler().removeCallbacks(longClickRunnable);
                }
                invalidate();
            }
            return true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                movingButton = null;
                setPressed(true);
                onClickCallback();

                invalidate();

                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                checkMovementForAllButtons(x, y);

                return true;
            }
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP: {
                setPressed(false);
                onReleaseCallback();

                checkMovementForAllButtons(x, y);

                invalidate();

                return true;
            }
            default: {
            }
        }
        return true;
    }
}
