package com.limelight.binding.input.virtual_controller;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Per-button appearance overrides. Anything left at its default follows the active theme.
 */
public final class ControlStyle {
    public static final int SHAPE_DEFAULT = -1;
    public static final int SHAPE_CIRCLE = 0;
    public static final int SHAPE_ROUNDED = 1;
    public static final int SHAPE_SQUARE = 2;
    public static final int SHAPE_PILL = 3;
    public static final int SHAPE_HEXAGON = 4;
    public static final int SHAPE_DIAMOND = 5;

    public static final String[] SHAPE_NAMES = {
            "Circle", "Rounded square", "Square", "Pill", "Hexagon", "Diamond"
    };

    public int shape = SHAPE_DEFAULT;
    /** 0 = follow theme, otherwise an RGB colour (alpha ignored). */
    public int color = 0;
    /** Opacity of this button in percent, multiplied with the global opacity. */
    public int alphaPct = 100;
    /** Emoji / symbol shown on the button, empty for none. */
    public String icon = "";
    /** null = automatic label. */
    public String label = null;
    /** WASD joystick sensitivity in percent. */
    public int sensitivity = 50;
    /** Toggle mode: one tap holds the button down, the next tap releases it. */
    public boolean toggle = false;

    public ControlStyle copy() {
        ControlStyle s = new ControlStyle();
        s.shape = shape;
        s.color = color;
        s.alphaPct = alphaPct;
        s.icon = icon;
        s.label = label;
        s.sensitivity = sensitivity;
        s.toggle = toggle;
        return s;
    }

    public boolean isDefault() {
        return shape == SHAPE_DEFAULT && color == 0 && alphaPct == 100 && icon.isEmpty()
                && label == null && sensitivity == 50 && !toggle;
    }

    public String toJson() {
        try {
            JSONObject o = new JSONObject();
            o.put("shape", shape);
            o.put("color", color);
            o.put("alpha", alphaPct);
            o.put("icon", icon);
            if (label != null) o.put("label", label);
            o.put("sens", sensitivity);
            if (toggle) o.put("toggle", true);
            return o.toString();
        } catch (JSONException e) {
            return "{}";
        }
    }

    public static ControlStyle fromJson(String json) {
        ControlStyle s = new ControlStyle();
        if (json == null) {
            return s;
        }
        try {
            JSONObject o = new JSONObject(json);
            s.shape = o.optInt("shape", SHAPE_DEFAULT);
            s.color = o.optInt("color", 0);
            s.alphaPct = o.optInt("alpha", 100);
            s.icon = o.optString("icon", "");
            s.label = o.has("label") ? o.optString("label") : null;
            s.sensitivity = o.optInt("sens", 50);
            s.toggle = o.optBoolean("toggle", false);
        } catch (JSONException e) {
            // fall through with defaults
        }
        return s;
    }
}
